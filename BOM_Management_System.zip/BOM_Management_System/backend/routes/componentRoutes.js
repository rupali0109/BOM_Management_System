const express = require("express");
const Component = require("../models/Component");
const router = express.Router();

router.post("/add", async (req, res) => {
  try {
    const { name, unitCost, unit } = req.body;
    
    // Validation
    if (!name || name.trim() === "") {
      return res.status(400).json({ error: "Component name is required" });
    }
    
    if (unitCost === undefined || unitCost === null) {
      return res.status(400).json({ error: "Unit cost is required" });
    }
    
    if (isNaN(unitCost) || unitCost < 0) {
      return res.status(400).json({ error: "Unit cost must be a valid positive number" });
    }

    const component = new Component({ 
      name: name.trim(), 
      unitCost: parseFloat(unitCost), 
      unit: unit ? unit.trim() : "" 
    });
    await component.save();
    res.json({ message: "Component added successfully", component });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

router.get("/", async (req, res) => {
  try {
    const components = await Component.find();
    res.json(components);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;
