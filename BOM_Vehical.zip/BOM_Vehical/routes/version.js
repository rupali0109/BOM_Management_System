const express = require('express');
const router = express.Router();
const Version = require('../models/Version');
const BOM = require('../models/BOM');

// Get all versions of a BOM
router.get('/bom/:bomId', async (req, res) => {
  try {
    const versions = await Version.find({ bomId: req.params.bomId })
      .populate('items.productId')
      .sort({ versionNumber: -1 });
    
    res.json({ versions });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Get specific version
router.get('/:id', async (req, res) => {
  try {
    const version = await Version.findById(req.params.id)
      .populate('items.productId');
    
    if (!version) {
      return res.status(404).json({ error: 'Version not found' });
    }
    
    res.json(version);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Compare two versions
router.get('/compare/:version1Id/:version2Id', async (req, res) => {
  try {
    const version1 = await Version.findById(req.params.version1Id)
      .populate('items.productId');
    const version2 = await Version.findById(req.params.version2Id)
      .populate('items.productId');
    
    if (!version1 || !version2) {
      return res.status(404).json({ error: 'One or both versions not found' });
    }
    
    const comparison = {
      version1: {
        versionNumber: version1.versionNumber,
        totalCost: version1.totalCost,
        itemCount: version1.items.length
      },
      version2: {
        versionNumber: version2.versionNumber,
        totalCost: version2.totalCost,
        itemCount: version2.items.length
      },
      differences: {
        costDifference: version2.totalCost - version1.totalCost,
        itemDifference: version2.items.length - version1.items.length,
        changes: findChanges(version1.items, version2.items)
      }
    };
    
    res.json(comparison);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Restore BOM to a specific version
router.post('/restore/:versionId', async (req, res) => {
  try {
    const version = await Version.findById(req.params.versionId)
      .populate('items.productId');
    
    if (!version) {
      return res.status(404).json({ error: 'Version not found' });
    }
    
    const bom = await BOM.findById(version.bomId);
    if (!bom) {
      return res.status(404).json({ error: 'BOM not found' });
    }
    
    // Restore items from version
    bom.items = version.items.map(item => ({
      productId: item.productId._id || item.productId,
      quantity: item.quantity,
      unitPrice: item.unitPrice,
      totalPrice: item.totalPrice
    }));
    
    bom.version = version.versionNumber;
    bom.updatedAt = Date.now();
    
    await bom.save();
    
    // Create new version for this restoration
    const newVersion = new Version({
      bomId: bom._id,
      versionNumber: bom.version + 1,
      changes: `Restored to version ${version.versionNumber}`,
      items: bom.items,
      totalCost: bom.totalCost,
      costDifference: bom.totalCost - version.totalCost
    });
    
    await newVersion.save();
    
    const updatedBom = await BOM.findById(bom._id)
      .populate('items.productId');
    
    res.json({
      message: 'BOM restored successfully',
      bom: updatedBom,
      restoredVersion: version.versionNumber
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

function findChanges(items1, items2) {
  const changes = [];
  const map1 = new Map(items1.map(item => [
    item.productId._id?.toString() || item.productId.toString(),
    item
  ]));
  const map2 = new Map(items2.map(item => [
    item.productId._id?.toString() || item.productId.toString(),
    item
  ]));
  
  // Find added items
  map2.forEach((item, id) => {
    if (!map1.has(id)) {
      changes.push({
        type: 'added',
        productId: id,
        quantity: item.quantity,
        price: item.totalPrice
      });
    }
  });
  
  // Find removed items
  map1.forEach((item, id) => {
    if (!map2.has(id)) {
      changes.push({
        type: 'removed',
        productId: id,
        quantity: item.quantity,
        price: item.totalPrice
      });
    }
  });
  
  // Find modified items
  map1.forEach((item1, id) => {
    if (map2.has(id)) {
      const item2 = map2.get(id);
      if (item1.quantity !== item2.quantity || item1.unitPrice !== item2.unitPrice) {
        changes.push({
          type: 'modified',
          productId: id,
          oldQuantity: item1.quantity,
          newQuantity: item2.quantity,
          oldPrice: item1.unitPrice,
          newPrice: item2.unitPrice
        });
      }
    }
  });
  
  return changes;
}

module.exports = router;
