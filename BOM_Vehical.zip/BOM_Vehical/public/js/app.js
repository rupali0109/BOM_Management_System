// Global State
let currentBOM = {
    name: '',
    description: '',
    vehicleType: 'E-Scooter',
    items: []
};

let allProducts = [];
let charts = {};

// Initialize App
document.addEventListener('DOMContentLoaded', () => {
    console.log('App initialized');
    initializeNavigation();
    loadDashboard();
    loadProducts();
    setupEventListeners();
    
    // Load all products for filtering
    ProductAPI.getAll().then(data => {
        allProducts = data.products || [];
    }).catch(err => {
        console.error('Error loading all products:', err);
    });
    
    // Also load products when products page is shown
    const productsNav = document.querySelector('[data-page="products"]');
    if (productsNav) {
        productsNav.addEventListener('click', () => {
            setTimeout(() => loadProducts(), 100);
        });
    }
});

// Navigation
function initializeNavigation() {
    document.querySelectorAll('.nav-item').forEach(item => {
        item.addEventListener('click', (e) => {
            e.preventDefault();
            const page = item.getAttribute('data-page');
            showPage(page);
        });
    });
}

function showPage(pageName) {
    // Hide all pages
    document.querySelectorAll('.page').forEach(page => {
        page.classList.remove('active');
    });
    
    // Remove active class from nav items
    document.querySelectorAll('.nav-item').forEach(item => {
        item.classList.remove('active');
    });
    
    // Show selected page
    const pageElement = document.getElementById(`${pageName}-page`);
    if (pageElement) {
        pageElement.classList.add('active');
        
        // Set active nav item
        const navItem = document.querySelector(`[data-page="${pageName}"]`);
        if (navItem) navItem.classList.add('active');
        
        // Load page data
        switch(pageName) {
            case 'dashboard':
                setTimeout(() => loadDashboard(), 100);
                break;
            case 'products':
                setTimeout(() => loadProducts(), 100);
                break;
            case 'bom-builder':
                setTimeout(() => {
                    loadBOMBuilder();
                    // Ensure all products are loaded for filtering
                    if (allProducts.length === 0) {
                        ProductAPI.getAll().then(data => {
                            allProducts = data.products || [];
                            loadAvailableProducts();
                        });
                    } else {
                        loadAvailableProducts();
                    }
                }, 100);
                break;
            case 'ai-suggestions':
                // AI page ready
                break;
            case 'version-history':
                setTimeout(() => loadBOMsForVersion(), 100);
                break;
            case 'analytics':
                setTimeout(() => loadAnalytics(), 100);
                break;
        }
    }
}

// Dashboard
async function loadDashboard() {
    try {
        const data = await AnalyticsAPI.getDashboard();
        
        // Update statistics
        document.getElementById('total-boms').textContent = data.statistics?.totalBOMs || 0;
        document.getElementById('active-boms').textContent = data.statistics?.activeBOMs || 0;
        document.getElementById('total-products').textContent = data.statistics?.totalProducts || 0;
        document.getElementById('total-cost').textContent = `₹${(data.statistics?.totalCost || 0).toLocaleString('en-IN')}`;
        
        // Load recent BOMs
        try {
            const recentBOMs = await BOMAPI.getAll({ limit: 5 });
            displayRecentBOMs(recentBOMs.boms || []);
        } catch (err) {
            console.error('Error loading recent BOMs:', err);
            displayRecentBOMs([]);
        }
        
        // Create charts - always create them, even with empty data
        createVehicleTypeChart(data.bomsByType || []);
        createCategoryChart(data.costByCategory || []);
    } catch (error) {
        console.error('Error loading dashboard:', error);
        // Set default values
        document.getElementById('total-boms').textContent = '0';
        document.getElementById('active-boms').textContent = '0';
        document.getElementById('total-products').textContent = '0';
        document.getElementById('total-cost').textContent = '₹0';
        displayRecentBOMs([]);
    }
}

function displayRecentBOMs(boms) {
    const container = document.getElementById('recent-boms-list');
    if (!container) return;
    if (!boms.length) {
        container.innerHTML = '<p>No BOMs found</p>';
        return;
    }
    
    container.innerHTML = boms.map(bom => `
        <div class="bom-item" data-bom-id="${bom._id}">
            <div class="bom-item-info recent-bom-click" style="flex: 1; cursor: pointer;">
                <h4>${bom.name}</h4>
                <p>${bom.vehicleType} • ${(bom.items || []).length} items • Status: ${bom.status || 'Draft'}</p>
            </div>
            <div style="display: flex; align-items: center; gap: 10px;">
                <div class="price">₹${(bom.totalCost || 0).toLocaleString('en-IN')}</div>
                <button type="button" class="btn-icon recent-bom-edit" data-bom-id="${bom._id}" title="Edit BOM">
                    <i class="fas fa-edit"></i>
                </button>
                <button type="button" class="btn-icon btn-danger recent-bom-delete" data-bom-id="${bom._id}" title="Delete BOM">
                    <i class="fas fa-trash"></i>
                </button>
            </div>
        </div>
    `).join('');
}

function createVehicleTypeChart(data) {
    const ctx = document.getElementById('vehicleTypeChart');
    if (!ctx) {
        console.warn('Vehicle type chart canvas not found');
        return;
    }
    
    // Destroy existing chart if any
    if (charts.vehicleType) {
        charts.vehicleType.destroy();
    }
    
    // Handle empty data
    if (!data || data.length === 0) {
        charts.vehicleType = new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: ['No BOMs Yet'],
                datasets: [{
                    data: [1],
                    backgroundColor: ['#e2e8f0']
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                aspectRatio: 1.3,
                plugins: {
                    legend: {
                        display: false
                    },
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                return 'Create BOMs to see distribution by vehicle type';
                            }
                        }
                    }
                }
            }
        });
        return;
    }
    
    // Create chart with data
    charts.vehicleType = new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: data.map(d => d._id || 'Unknown'),
            datasets: [{
                data: data.map(d => d.count || 0),
                backgroundColor: [
                    '#2563eb', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6',
                    '#ec4899', '#06b6d4', '#84cc16'
                ]
            }]
        },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                aspectRatio: 1.3,
                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: {
                            boxWidth: 14,
                            padding: 10,
                            font: {
                                size: 12
                            }
                        }
                    },
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                const label = context.label || '';
                                const value = context.parsed || 0;
                                return label + ': ' + value + ' BOM(s)';
                            }
                        }
                    }
                }
            }
    });
}

function createCategoryChart(data) {
    const ctx = document.getElementById('categoryChart');
    if (!ctx) {
        console.warn('Category chart canvas not found');
        return;
    }
    
    // Destroy existing chart if any
    if (charts.category) {
        charts.category.destroy();
    }
    
    // Handle empty data
    if (!data || data.length === 0) {
        charts.category = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: ['No BOMs Created Yet'],
                datasets: [{
                    label: 'Cost (₹)',
                    data: [0],
                    backgroundColor: '#e2e8f0'
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: true,
                plugins: {
                    legend: {
                        display: false
                    },
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                return 'Create BOMs to see cost breakdown by category';
                            }
                        }
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            callback: function(value) {
                                return '₹' + value.toLocaleString('en-IN');
                            }
                        }
                    }
                }
            }
        });
        return;
    }
    
    // Create chart with data
    const labels = data.map(d => d._id || 'Unknown');
    const costs = data.map(d => d.totalCost || 0);
    
    // Generate colors for each category
    const colors = [
        '#2563eb', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6',
        '#ec4899', '#06b6d4', '#84cc16', '#f97316', '#6366f1'
    ];
    
    charts.category = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: labels,
            datasets: [{
                label: 'Cost (₹)',
                data: costs,
                backgroundColor: labels.map((_, i) => colors[i % colors.length]),
                borderColor: labels.map((_, i) => colors[i % colors.length]),
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: true,
            plugins: {
                legend: {
                    display: false
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return 'Cost: ₹' + context.parsed.y.toLocaleString('en-IN');
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        callback: function(value) {
                            return '₹' + value.toLocaleString('en-IN');
                        }
                    }
                },
                x: {
                    ticks: {
                        maxRotation: 45,
                        minRotation: 0
                    }
                }
            }
        }
    });
}

// Products
async function loadProducts() {
    try {
        console.log('Loading products...');
        const data = await ProductAPI.getAll();
        console.log('Products data received:', data);
        allProducts = data.products || [];
        
        if (allProducts.length === 0) {
            console.warn('No products found in API response');
        }
        
        displayProducts(allProducts);
    } catch (error) {
        console.error('Error loading products:', error);
        // Display empty state instead of showing error
        allProducts = [];
        displayProducts([]);
        showNotification('Failed to load products. Please check server connection.', 'error');
    }
}

function displayProducts(products) {
    const container = document.getElementById('products-grid');
    if (!container) {
        console.error('Products grid container not found');
        return;
    }
    
    if (!products || products.length === 0) {
        container.innerHTML = '<div style="grid-column: 1/-1; text-align: center; padding: 40px;"><p style="font-size: 18px; color: var(--text-secondary);">No products found</p><p style="margin-top: 10px; color: var(--text-secondary);">Click "Add Product" to create your first product</p></div>';
        return;
    }
    
    console.log(`Displaying ${products.length} products`);
    container.innerHTML = products.map(product => `
        <div class="product-card">
            <span class="category">${product.category || 'Uncategorized'}</span>
            <h3>${product.name || 'Unnamed Product'}</h3>
            <p class="text-secondary">${product.partNumber || 'N/A'}</p>
            <p style="font-size: 13px; color: var(--text-secondary); margin: 10px 0;">${product.description || 'No description available'}</p>
            <div class="price">₹${(product.basePrice || 0).toLocaleString('en-IN')}</div>
            ${product.stock !== undefined ? `<p style="font-size: 12px; margin-top: 5px; color: var(--text-secondary);">Stock: ${product.stock}</p>` : ''}
        </div>
    `).join('');
}

// Product Search and Filter
document.getElementById('product-search')?.addEventListener('input', (e) => {
    const searchTerm = e.target.value.toLowerCase();
    const filtered = allProducts.filter(p => 
        p.name.toLowerCase().includes(searchTerm) ||
        p.partNumber.toLowerCase().includes(searchTerm)
    );
    displayProducts(filtered);
});

document.getElementById('category-filter')?.addEventListener('change', (e) => {
    const category = e.target.value;
    if (category) {
        ProductAPI.getByCategory(category).then(data => {
            displayProducts(data);
        });
    } else {
        loadProducts();
    }
});

// Edit BOM (from Recent BOMs)
async function editBOM(bomId) {
    try {
        showNotification('Loading BOM...', 'info');
        const bom = await BOMAPI.getById(bomId);
        if (!bom) {
            showNotification('BOM not found', 'error');
            return;
        }
        
        // Map API items - backend sends item.productId (string) and item.product { name, category, ... }
        const items = [];
        for (let idx = 0; idx < (bom.items || []).length; idx++) {
            const item = bom.items[idx];
            const productIdStr = item.productId ? String(item.productId) : '';
            let product = null;
            
            // Use product from backend if available
            if (item.product && item.product.name) {
                product = {
                    _id: item.product._id || productIdStr,
                    name: String(item.product.name),
                    category: item.product.category || '',
                    basePrice: item.product.basePrice != null ? item.product.basePrice : (item.unitPrice || 0)
                };
            }
            
            // If no product name, fetch it immediately
            if (!product || !product.name) {
                if (productIdStr) {
                    try {
                        const fetchedProduct = await ProductAPI.getById(productIdStr);
                        if (fetchedProduct && fetchedProduct.name) {
                            product = {
                                _id: fetchedProduct._id,
                                name: String(fetchedProduct.name),
                                category: fetchedProduct.category || '',
                                basePrice: fetchedProduct.basePrice != null ? fetchedProduct.basePrice : (item.unitPrice || 0)
                            };
                        }
                    } catch (err) {
                        console.error(`Failed to fetch product ${productIdStr}:`, err);
                    }
                }
            }
            
            // Fallback if still no product
            if (!product || !product.name) {
                product = {
                    _id: productIdStr,
                    name: 'Unknown Product',
                    category: '',
                    basePrice: item.unitPrice || 0
                };
            }
            
            const unitPrice = item.unitPrice != null ? Number(item.unitPrice) : (product.basePrice || 0);
            const quantity = item.quantity != null ? Number(item.quantity) : 1;
            const totalPrice = item.totalPrice != null ? Number(item.totalPrice) : (unitPrice * quantity);
            
            items.push({
                productId: productIdStr,
                product: product,
                quantity: quantity,
                unitPrice: unitPrice,
                totalPrice: totalPrice
            });
        }
        
        currentBOM = {
            _id: bom._id,
            name: bom.name,
            description: bom.description || '',
            vehicleType: bom.vehicleType || 'E-Scooter',
            items: items
        };
        
        document.getElementById('bom-name').value = currentBOM.name;
        document.getElementById('bom-description').value = currentBOM.description;
        const vehicleSelect = document.getElementById('vehicle-type-select');
        if (vehicleSelect) vehicleSelect.value = currentBOM.vehicleType;
        const statusSelect = document.getElementById('bom-status-select');
        if (statusSelect) statusSelect.value = bom.status || 'Draft';
        showPage('bom-builder');
        updateBOMDisplay();
        loadAvailableProducts();
        showNotification('BOM loaded for editing', 'success');
    } catch (error) {
        console.error('Error loading BOM for edit:', error);
        showNotification('Failed to load BOM for editing', 'error');
    }
}

// Fetch and fill product names for BOM items that have productId but missing product.name
async function fillProductNamesForBOMItems() {
    if (!currentBOM || !currentBOM.items || currentBOM.items.length === 0) {
        console.log('fillProductNamesForBOMItems: No items to fill');
        return;
    }
    const needFetch = [];
    for (let i = 0; i < currentBOM.items.length; i++) {
        const item = currentBOM.items[i];
        const id = item.productId;
        if (id == null || id === '') {
            console.log(`fillProductNamesForBOMItems: Item ${i} missing productId`);
            continue;
        }
        const idStr = typeof id === 'object' ? (id._id || id?.$oid || id) : id;
        const idStrClean = String(idStr).trim();
        const hasName = item.product && item.product.name && item.product.name !== '';
        if (!hasName && idStrClean) {
            console.log(`fillProductNamesForBOMItems: Item ${i} needs fetch, productId:`, idStrClean);
            needFetch.push({ item, index: i, idStr: idStrClean });
        } else {
            console.log(`fillProductNamesForBOMItems: Item ${i} already has name:`, item.product?.name);
        }
    }
    if (needFetch.length === 0) {
        console.log('fillProductNamesForBOMItems: All items have names, no fetch needed');
        return;
    }
    console.log('fillProductNamesForBOMItems: Fetching', needFetch.length, 'products');
    try {
        const results = await Promise.all(
            needFetch.map(({ idStr }) => {
                console.log('Fetching product from API:', idStr);
                return ProductAPI.getById(idStr).then(p => {
                    console.log('Product API response for', idStr, ':', p);
                    return p;
                }).catch((err) => {
                    console.error('Failed to fetch product', idStr, ':', err);
                    return null;
                });
            })
        );
        needFetch.forEach(({ item, index, idStr }, idx) => {
            const p = results[idx];
            console.log(`Processing result ${idx} for item ${index}, productId: ${idStr}, response:`, p);
            if (p && p.name) {
                item.product = {
                    _id: p._id,
                    name: String(p.name),
                    category: p.category != null ? String(p.category) : '',
                    basePrice: p.basePrice != null ? p.basePrice : item.unitPrice
                };
                console.log(`✓ Item ${index}: Filled product name "${item.product.name}"`);
            } else {
                console.warn(`✗ Item ${index}: Could not fetch product, productId: ${idStr}, response:`, p);
                // Set a fallback so we don't show "Loading..." forever
                item.product = {
                    _id: item.productId,
                    name: 'Unknown Product',
                    category: '',
                    basePrice: item.unitPrice || 0
                };
            }
        });
        console.log('fillProductNamesForBOMItems: Completed. Final items:', currentBOM.items.map((i, idx) => ({ idx, productId: i.productId, name: i.product?.name || 'NO NAME' })));
    } catch (error) {
        console.error('fillProductNamesForBOMItems: Error fetching products:', error);
    }
}

// Start fresh BOM (for Create New BOM button)
function createNewBOM() {
    currentBOM = {
        name: '',
        description: '',
        vehicleType: document.getElementById('vehicle-type-select')?.value || 'E-Scooter',
        items: []
    };
}

// Delete BOM (from Recent BOMs)
async function deleteBOM(bomId) {
    if (!confirm('Are you sure you want to delete this BOM? This action cannot be undone.')) return;
    try {
        await BOMAPI.delete(bomId);
        showNotification('BOM deleted successfully', 'success');
        loadDashboard();
    } catch (error) {
        console.error('Error deleting BOM:', error);
        showNotification('Failed to delete BOM: ' + (error.message || 'Unknown error'), 'error');
    }
}

// BOM Builder
function loadBOMBuilder() {
    // If we're editing an existing BOM (currentBOM._id set by editBOM), don't reset
    if (currentBOM && currentBOM._id) {
        updateBOMDisplay();
        const vehicleType = document.getElementById('vehicle-type-select')?.value || currentBOM.vehicleType;
        const filterIndicator = document.getElementById('filter-indicator');
        if (filterIndicator) {
            filterIndicator.textContent = `Filtered by: ${vehicleType}`;
            filterIndicator.style.display = 'inline-block';
        }
        loadAvailableProducts();
        return;
    }
    currentBOM = {
        name: '',
        description: '',
        vehicleType: document.getElementById('vehicle-type-select')?.value || 'E-Scooter',
        items: []
    };
    updateBOMDisplay();
    
    // Initialize filter indicator
    const filterIndicator = document.getElementById('filter-indicator');
    const vehicleType = document.getElementById('vehicle-type-select')?.value || 'E-Scooter';
    if (filterIndicator) {
        filterIndicator.textContent = `Filtered by: ${vehicleType}`;
        filterIndicator.style.display = 'inline-block';
    }
    
    loadAvailableProducts();
    
    // Add event listener for vehicle type change (only once)
    const vehicleTypeSelect = document.getElementById('vehicle-type-select');
    if (vehicleTypeSelect && !vehicleTypeSelect.dataset.listenerAdded) {
        vehicleTypeSelect.addEventListener('change', (e) => {
            currentBOM.vehicleType = e.target.value;
            console.log('Vehicle type changed to:', e.target.value);
            loadAvailableProducts();
        });
        vehicleTypeSelect.dataset.listenerAdded = 'true';
    }
}

async function loadAvailableProducts() {
    try {
        const vehicleType = document.getElementById('vehicle-type-select')?.value || 'E-Scooter';
        
        // Use allProducts if available, otherwise fetch
        let products = allProducts.length > 0 ? allProducts : [];
        
        if (products.length === 0) {
            const data = await ProductAPI.getAll();
            products = data.products || [];
            allProducts = products; // Cache for future use
        }
        
        // Filter products based on vehicle type compatibility
        let filteredProducts = products;
        if (vehicleType && vehicleType !== 'Other') {
            filteredProducts = products.filter(product => {
                // If product has compatibility array, check if it includes the vehicle type
                if (product.compatibility && product.compatibility.length > 0) {
                    return product.compatibility.includes(vehicleType);
                }
                // If no compatibility specified, show all products (universal compatibility)
                return true;
            });
        }
        
        console.log(`Filtered ${filteredProducts.length} products for ${vehicleType} out of ${products.length} total`);
        
        // Show message if no compatible products
        if (filteredProducts.length === 0) {
            const container = document.getElementById('available-products');
            container.innerHTML = `
                <div style="text-align: center; padding: 40px; color: var(--text-secondary);">
                    <i class="fas fa-info-circle" style="font-size: 48px; margin-bottom: 15px; opacity: 0.5; color: var(--primary-color);"></i>
                    <p style="font-size: 16px; margin-bottom: 10px; font-weight: 600;">No compatible products found for <strong>${vehicleType}</strong></p>
                    <p style="font-size: 14px; margin-bottom: 20px;">Try selecting a different vehicle type</p>
                    <button class="btn btn-primary" onclick="document.getElementById('vehicle-type-select').value='E-Scooter'; loadAvailableProducts();">
                        Show E-Scooter Products
                    </button>
                </div>
            `;
            return;
        }
        
        displayAvailableProducts(filteredProducts);
    } catch (error) {
        console.error('Error loading products:', error);
        showNotification('Error loading compatible products', 'error');
        
        // Update filter indicator even on error
        const filterIndicator = document.getElementById('filter-indicator');
        if (filterIndicator) {
            filterIndicator.textContent = `Filtered by: ${document.getElementById('vehicle-type-select')?.value || 'E-Scooter'}`;
        }
    }
}

function displayAvailableProducts(products) {
    const container = document.getElementById('available-products');
    if (!products || products.length === 0) {
        return; // Message already shown in loadAvailableProducts
    }
    
    container.innerHTML = products.map(product => {
        const compatibility = product.compatibility && product.compatibility.length > 0 
            ? product.compatibility.join(', ') 
            : 'All types';
        
        return `
        <div class="product-card" onclick="addToBOM('${product._id}')">
            <div style="display: flex; justify-content: space-between; align-items: start; margin-bottom: 8px;">
                <span class="category">${product.category || 'Uncategorized'}</span>
                ${product.compatibility && product.compatibility.length > 0 
                    ? `<span style="font-size: 10px; padding: 2px 6px; background: rgba(79, 70, 229, 0.1); color: var(--primary-color); border-radius: 4px;">${compatibility}</span>` 
                    : ''}
            </div>
            <h4>${product.name || 'Unnamed Product'}</h4>
            <p class="text-secondary" style="font-size: 12px;">${product.partNumber || 'N/A'}</p>
            ${product.description ? `<p style="font-size: 11px; color: var(--text-secondary); margin: 8px 0;">${product.description.substring(0, 60)}${product.description.length > 60 ? '...' : ''}</p>` : ''}
            <div class="price">₹${(product.basePrice || 0).toLocaleString('en-IN')}</div>
            ${product.stock !== undefined ? `<p style="font-size: 11px; margin-top: 5px; color: var(--text-secondary);">Stock: ${product.stock}</p>` : ''}
        </div>
    `;
    }).join('');
}

async function addToBOM(productId) {
    try {
        const product = await ProductAPI.getById(productId);
        const existingItem = currentBOM.items.find(item => item.productId === productId);
        
        if (existingItem) {
            existingItem.quantity += 1;
            existingItem.totalPrice = existingItem.unitPrice * existingItem.quantity;
        } else {
            currentBOM.items.push({
                productId: productId,
                product: product,
                quantity: 1,
                unitPrice: product.basePrice,
                totalPrice: product.basePrice
            });
        }
        
        updateBOMDisplay();
    } catch (error) {
        console.error('Error adding product to BOM:', error);
        showNotification('Error adding product', 'error');
    }
}

function removeFromBOM(index) {
    currentBOM.items.splice(index, 1);
    updateBOMDisplay();
}

function updateBOMQuantity(index, quantity) {
    const item = currentBOM.items[index];
    item.quantity = parseInt(quantity) || 1;
    item.totalPrice = item.unitPrice * item.quantity;
    updateBOMDisplay();
}

function getItemDisplayName(item) {
    if (item.product && item.product.name && item.product.name !== '' && item.product.name !== 'Unknown Product') {
        return item.product.name;
    }
    if (item.productId && typeof item.productId === 'object' && item.productId.name) {
        return item.productId.name;
    }
    return null;
}

function updateBOMDisplay() {
    const container = document.getElementById('bom-items-list');
    if (!container) return;
    const totalItems = currentBOM.items.length;
    const totalCost = currentBOM.items.reduce((sum, item) => sum + (item.totalPrice || 0), 0);
    
    const totalEl = document.getElementById('total-items');
    const costEl = document.getElementById('bom-total-cost');
    if (totalEl) totalEl.textContent = totalItems;
    if (costEl) costEl.textContent = `₹${totalCost.toLocaleString('en-IN')}`;
    
    if (!totalItems) {
        container.innerHTML = '<p class="text-center">No items yet. Add products from the products panel.</p>';
        return;
    }
    
    container.innerHTML = currentBOM.items.map((item, index) => {
        let name = getItemDisplayName(item);
        if (!name) {
            // Try to show productId or fallback
            if (item.productId) {
                const pid = String(item.productId);
                name = `Product ${pid.substring(0, 8)}${pid.length > 8 ? '...' : ''}`;
            } else {
                name = 'Unknown Product';
            }
        }
        const category = (item.product && item.product.category) || (item.productId && typeof item.productId === 'object' && item.productId.category) || '';
        return `
        <div class="bom-item">
            <div class="bom-item-info">
                <h4>${name}</h4>
                <p>${category} • ₹${(item.unitPrice || 0).toLocaleString('en-IN')}/unit</p>
            </div>
            <div class="bom-item-controls">
                <input type="number" value="${item.quantity}" min="1" 
                    onchange="updateBOMQuantity(${index}, this.value)">
                <span>₹${(item.totalPrice || 0).toLocaleString('en-IN')}</span>
                <button class="btn btn-secondary" onclick="removeFromBOM(${index})">
                    <i class="fas fa-trash"></i>
                </button>
            </div>
        </div>
    `;
    }).join('');
}

async function saveBOM() {
    try {
        const name = document.getElementById('bom-name').value;
        if (!name) {
            showNotification('Please enter BOM name', 'error');
            return;
        }
        
        // Get status from selector if available
        const statusSelect = document.getElementById('bom-status-select');
        const status = statusSelect ? statusSelect.value : 'Draft';
        
        // Ensure productId is always string (in case it was stored as object from API)
        const bomData = {
            name,
            description: document.getElementById('bom-description').value,
            vehicleType: document.getElementById('vehicle-type-select').value,
            status: status,
            items: currentBOM.items.map(item => {
                const pid = item.productId;
                const productIdStr = (pid && typeof pid === 'object' && pid._id) ? pid._id : String(pid || '');
                return {
                    productId: productIdStr,
                    quantity: Math.max(1, parseInt(item.quantity, 10) || 1)
                };
            })
        };
        
        let savedBOM;
        if (currentBOM._id) {
            // Update existing BOM
            savedBOM = await BOMAPI.update(currentBOM._id, bomData);
            showNotification(`BOM updated successfully as ${status}!`, 'success');
        } else {
            // Create new BOM
            savedBOM = await BOMAPI.create(bomData);
            showNotification(`BOM saved successfully as ${status}!`, 'success');
        }
        
        // Reset form
        document.getElementById('bom-name').value = '';
        document.getElementById('bom-description').value = '';
        const statusSelectReset = document.getElementById('bom-status-select');
        if (statusSelectReset) statusSelectReset.value = 'Draft';
        currentBOM.items = [];
        currentBOM._id = null;
        updateBOMDisplay();
        
        // Refresh dashboard if on dashboard page
        if (document.getElementById('dashboard-page').classList.contains('active')) {
            loadDashboard();
        }
    } catch (error) {
        console.error('Error saving BOM:', error);
        const msg = (error && error.message) ? error.message : 'Error saving BOM';
        showNotification(msg, 'error');
    }
}

async function optimizeBOM() {
    // Check if BOM has items
    if (!currentBOM.items || currentBOM.items.length === 0) {
        showNotification('Please add products to BOM first', 'error');
        return;
    }
    
    // Calculate current cost
    const currentCost = currentBOM.items.reduce((sum, item) => sum + item.totalPrice, 0);
    
    // Show optimization modal
    showOptimizeModal(currentCost);
}

function showOptimizeModal(currentCost) {
    // Create modal HTML
    const modalHTML = `
        <div id="optimize-modal" class="modal active">
            <div class="modal-content" style="max-width: 600px;">
                <span class="close" onclick="closeModal('optimize-modal')">&times;</span>
                <h2>Optimize BOM Cost</h2>
                <div style="margin-bottom: 20px;">
                    <p><strong>Current Total Cost:</strong> ₹${currentCost.toLocaleString('en-IN')}</p>
                </div>
                <div class="form-group">
                    <label>Target Price (₹) *</label>
                    <input type="number" id="target-price-input" class="form-input" 
                        placeholder="Enter target price" min="0" step="0.01" required>
                    <small>Enter the maximum price you want to achieve</small>
                </div>
                <div id="optimize-results" style="margin-top: 20px; display: none;"></div>
                <div class="form-actions">
                    <button type="button" class="btn btn-secondary" onclick="closeModal('optimize-modal')">Cancel</button>
                    <button type="button" class="btn btn-primary" onclick="runOptimization(${currentCost})">
                        <i class="fas fa-magic"></i> Optimize
                    </button>
                </div>
            </div>
        </div>
    `;
    
    // Remove existing modal if any
    const existingModal = document.getElementById('optimize-modal');
    if (existingModal) existingModal.remove();
    
    // Add modal to body
    document.body.insertAdjacentHTML('beforeend', modalHTML);
}

async function runOptimization(currentCost) {
    const targetPrice = parseFloat(document.getElementById('target-price-input').value);
    const resultsDiv = document.getElementById('optimize-results');
    
    if (!targetPrice || targetPrice <= 0) {
        showNotification('Please enter a valid target price', 'error');
        return;
    }
    
    if (targetPrice >= currentCost) {
        showNotification('Target price should be less than current cost', 'error');
        return;
    }
    
    try {
        resultsDiv.style.display = 'block';
        resultsDiv.innerHTML = '<p>Analyzing alternatives...</p>';
        
        // For new BOM, we need to simulate optimization
        // Since we don't have a saved BOM ID yet, we'll do client-side optimization
        const optimizationResult = await optimizeBOMClientSide(currentCost, targetPrice);
        displayOptimizationResults(optimizationResult, currentCost, targetPrice);
    } catch (error) {
        console.error('Error optimizing BOM:', error);
        showNotification('Error optimizing BOM: ' + error.message, 'error');
    }
}

async function optimizeBOMClientSide(currentCost, targetPrice) {
    const savingsNeeded = currentCost - targetPrice;
    const recommendations = [];
    let totalSavings = 0;
    
    // For each item in current BOM, find cheaper alternatives
    for (let item of currentBOM.items) {
        if (!item.productId) continue;
        
        try {
            const product = await ProductAPI.getById(item.productId);
            const alternatives = await ProductAPI.getAll({ 
                category: product.category,
                limit: 50 
            });
            
            // Find cheaper alternatives
            const cheaperAlternatives = alternatives.products
                .filter(p => p._id !== product._id && p.basePrice < product.basePrice)
                .sort((a, b) => a.basePrice - b.basePrice)
                .slice(0, 3);
            
            if (cheaperAlternatives.length > 0 && totalSavings < savingsNeeded) {
                const alternative = cheaperAlternatives[0];
                const savings = (product.basePrice - alternative.basePrice) * item.quantity;
                
                recommendations.push({
                    original: {
                        id: product._id,
                        name: product.name,
                        price: product.basePrice,
                        partNumber: product.partNumber
                    },
                    alternative: {
                        id: alternative._id,
                        name: alternative.name,
                        price: alternative.basePrice,
                        partNumber: alternative.partNumber
                    },
                    quantity: item.quantity,
                    savings: savings,
                    category: product.category
                });
                
                totalSavings += savings;
            } else {
                recommendations.push({
                    original: {
                        id: product._id,
                        name: product.name,
                        price: product.basePrice,
                        partNumber: product.partNumber
                    },
                    alternative: null,
                    quantity: item.quantity,
                    savings: 0,
                    category: product.category
                });
            }
        } catch (error) {
            console.error('Error finding alternatives for product:', error);
        }
    }
    
    return {
        optimized: totalSavings > 0,
        originalCost: currentCost,
        optimizedCost: currentCost - totalSavings,
        savings: totalSavings,
        targetPrice: targetPrice,
        recommendations: recommendations,
        message: totalSavings >= savingsNeeded 
            ? 'Target price achievable!' 
            : `Can save ₹${totalSavings.toFixed(2)}, need ₹${(savingsNeeded - totalSavings).toFixed(2)} more`
    };
}

function displayOptimizationResults(result, currentCost, targetPrice) {
    const resultsDiv = document.getElementById('optimize-results');
    
    let html = `
        <div style="background: var(--light-bg); padding: 20px; border-radius: 8px; margin-top: 20px;">
            <h3 style="margin-bottom: 15px;">Optimization Results</h3>
            <div style="display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 15px; margin-bottom: 20px;">
                <div>
                    <strong>Current Cost:</strong><br>
                    <span style="font-size: 18px; color: var(--text-primary);">₹${currentCost.toLocaleString('en-IN')}</span>
                </div>
                <div>
                    <strong>Target Cost:</strong><br>
                    <span style="font-size: 18px; color: var(--primary-color);">₹${targetPrice.toLocaleString('en-IN')}</span>
                </div>
                <div>
                    <strong>Optimized Cost:</strong><br>
                    <span style="font-size: 18px; color: ${result.optimizedCost <= targetPrice ? 'var(--secondary-color)' : 'var(--warning-color)'};">
                        ₹${result.optimizedCost.toLocaleString('en-IN')}
                    </span>
                </div>
            </div>
            <div style="margin-bottom: 15px;">
                <strong>Potential Savings:</strong> 
                <span style="color: var(--secondary-color); font-size: 16px;">₹${result.savings.toLocaleString('en-IN')}</span>
            </div>
            <p style="color: ${result.optimizedCost <= targetPrice ? 'var(--secondary-color)' : 'var(--warning-color)'}; font-weight: 600;">
                ${result.message}
            </p>
        </div>
    `;
    
    if (result.recommendations && result.recommendations.length > 0) {
        html += '<div style="margin-top: 20px;"><h4>Recommendations:</h4>';
        
        result.recommendations.forEach((rec, index) => {
            if (rec.alternative) {
                html += `
                    <div style="background: white; padding: 15px; border-radius: 8px; margin-bottom: 10px; border-left: 4px solid var(--secondary-color);">
                        <div style="display: flex; justify-content: space-between; align-items: start;">
                            <div style="flex: 1;">
                                <p><strong>${rec.original.name}</strong></p>
                                <p style="font-size: 12px; color: var(--text-secondary);">${rec.original.partNumber}</p>
                                <p style="margin-top: 5px;">Current: ₹${rec.original.price.toLocaleString('en-IN')} × ${rec.quantity} = ₹${(rec.original.price * rec.quantity).toLocaleString('en-IN')}</p>
                            </div>
                            <div style="text-align: right; margin-left: 20px;">
                                <i class="fas fa-arrow-right" style="margin: 10px;"></i>
                            </div>
                            <div style="flex: 1; text-align: right;">
                                <p><strong style="color: var(--secondary-color);">${rec.alternative.name}</strong></p>
                                <p style="font-size: 12px; color: var(--text-secondary);">${rec.alternative.partNumber}</p>
                                <p style="margin-top: 5px;">New: ₹${rec.alternative.price.toLocaleString('en-IN')} × ${rec.quantity} = ₹${(rec.alternative.price * rec.quantity).toLocaleString('en-IN')}</p>
                                <p style="color: var(--secondary-color); font-weight: 600; margin-top: 5px;">
                                    Save: ₹${rec.savings.toLocaleString('en-IN')}
                                </p>
                                <button class="btn btn-primary btn-sm" onclick="applyOptimization('${rec.alternative.id}', ${index})" style="margin-top: 5px;">
                                    Apply
                                </button>
                            </div>
                        </div>
                    </div>
                `;
            }
        });
        
        html += '</div>';
    }
    
    resultsDiv.innerHTML = html;
}

async function applyOptimization(alternativeProductId, recommendationIndex) {
    try {
        // Replace the product in current BOM
        const product = await ProductAPI.getById(alternativeProductId);
        const itemIndex = currentBOM.items.findIndex(item => 
            item.productId === currentBOM.items[recommendationIndex]?.productId
        );
        
        if (itemIndex !== -1) {
            currentBOM.items[itemIndex].productId = alternativeProductId;
            currentBOM.items[itemIndex].product = product;
            currentBOM.items[itemIndex].unitPrice = product.basePrice;
            currentBOM.items[itemIndex].totalPrice = product.basePrice * currentBOM.items[itemIndex].quantity;
            
            updateBOMDisplay();
            showNotification('Product replaced successfully!', 'success');
            closeModal('optimize-modal');
        }
    } catch (error) {
        console.error('Error applying optimization:', error);
        showNotification('Error applying optimization', 'error');
    }
}

// AI Suggestions
async function getAISuggestions() {
    const vehicleType = document.getElementById('ai-vehicle-type').value;
    const budget = parseFloat(document.getElementById('ai-budget').value);
    
    if (!budget || budget <= 0) {
        showNotification('Please enter a valid budget', 'error');
        return;
    }
    
    try {
        const results = await AIAPI.suggest({
            vehicleType,
            budget,
            existingComponents: currentBOM.items.map(item => ({
                productId: item.productId,
                category: item.product?.category,
                price: item.unitPrice
            }))
        });
        
        displayAISuggestions(results);
    } catch (error) {
        console.error('Error getting AI suggestions:', error);
        showNotification('Error loading AI suggestions', 'error');
    }
}

function displayAISuggestions(results) {
    const container = document.getElementById('ai-results');
    
    let html = `
        <div class="ai-summary">
            <h2>AI Recommendations</h2>
            <p><strong>Budget:</strong> ₹${results.budget.toLocaleString('en-IN')}</p>
            <p><strong>Estimated Cost:</strong> ₹${results.totalEstimate.toLocaleString('en-IN')}</p>
            <p><strong>Remaining:</strong> ₹${results.budgetRemaining.toLocaleString('en-IN')}</p>
            <p><strong>Confidence:</strong> ${results.confidence.toFixed(1)}%</p>
        </div>
    `;
    
    // Essential components
    if (results.recommendations.essential.length) {
        html += '<div class="suggestion-group"><h3>Essential Components</h3>';
        results.recommendations.essential.forEach(group => {
            group.products.forEach(product => {
                html += `
                    <div class="suggestion-item">
                        <h4>${product.name}</h4>
                        <p>${group.category} • ₹${product.price.toLocaleString('en-IN')}</p>
                        <p><small>${product.reason}</small></p>
                        <button class="btn btn-primary btn-sm" onclick="addToBOMFromAI('${product.id}')">Add</button>
                    </div>
                `;
            });
        });
        html += '</div>';
    }
    
    // Recommended components
    if (results.recommendations.recommended.length) {
        html += '<div class="suggestion-group"><h3>Recommended Components</h3>';
        results.recommendations.recommended.forEach(group => {
            group.products.forEach(product => {
                html += `
                    <div class="suggestion-item">
                        <h4>${product.name}</h4>
                        <p>${group.category} • ₹${product.price.toLocaleString('en-IN')}</p>
                        <p><small>${product.reason}</small></p>
                        <button class="btn btn-primary btn-sm" onclick="addToBOMFromAI('${product.id}')">Add</button>
                    </div>
                `;
            });
        });
        html += '</div>';
    }
    
    container.innerHTML = html;
}

async function addToBOMFromAI(productId) {
    await addToBOM(productId);
    showPage('bom-builder');
}

// BOM History
async function loadBOMsForVersion() {
    try {
        const data = await BOMAPI.getAll();
        const select = document.getElementById('bom-select-version');
        select.innerHTML = '<option value="">Select BOM...</option>' +
            data.boms.map(bom => `<option value="${bom._id}">${bom.name}</option>`).join('');
        
        select.addEventListener('change', async (e) => {
            if (e.target.value) {
                await loadVersions(e.target.value);
            }
        });
    } catch (error) {
        console.error('Error loading BOMs:', error);
    }
}

async function loadVersions(bomId) {
    try {
        const data = await VersionAPI.getByBOM(bomId);
        displayVersions(data.versions || []);
    } catch (error) {
        console.error('Error loading versions:', error);
    }
}

function displayVersions(versions) {
    const container = document.getElementById('version-list');
    if (!versions.length) {
        container.innerHTML = '<p>No versions found</p>';
        return;
    }
    
    container.innerHTML = versions.map(version => `
        <div class="version-card">
            <div class="version-header">
                <span class="version-number">Version ${version.versionNumber}</span>
                <span class="version-date">${new Date(version.createdAt).toLocaleDateString('en-IN')}</span>
            </div>
            <p><strong>Changes:</strong> ${version.changes || 'No changes recorded'}</p>
            <p><strong>Total Cost:</strong> ₹${version.totalCost.toLocaleString('en-IN')}</p>
            ${version.costDifference !== 0 ? `<p><strong>Cost Difference:</strong> ₹${version.costDifference.toLocaleString('en-IN')}</p>` : ''}
            <div style="display: flex; gap: 10px; margin-top: 15px;">
                <button class="btn btn-primary" onclick="restoreVersion('${version._id}')">
                    <i class="fas fa-undo"></i> Restore
                </button>
            </div>
        </div>
    `).join('');
}

async function restoreVersion(versionId) {
    if (!confirm('Do you want to restore this version?')) return;
    
    try {
        await VersionAPI.restore(versionId);
        showNotification('Version restored successfully', 'success');
        loadVersions(document.getElementById('bom-select-version').value);
    } catch (error) {
        console.error('Error restoring version:', error);
        showNotification('Error restoring version', 'error');
    }
}

// Analytics
async function loadAnalytics() {
    try {
        const trends = await AnalyticsAPI.getTrends(30);
        const categories = await AnalyticsAPI.getCategories();
        
        createCostTrendChart(trends.trends);
        createCategoryDistChart(categories.distribution);
    } catch (error) {
        console.error('Error loading analytics:', error);
    }
}

function createCostTrendChart(trends) {
    const ctx = document.getElementById('costTrendChart');
    if (!ctx) return;
    
    if (charts.costTrend) charts.costTrend.destroy();
    
    charts.costTrend = new Chart(ctx, {
        type: 'line',
        data: {
            labels: trends.map(t => new Date(t.date).toLocaleDateString('en-IN')),
            datasets: [{
                label: 'Cost (₹)',
                data: trends.map(t => t.cost),
                borderColor: '#2563eb',
                backgroundColor: 'rgba(37, 99, 235, 0.1)',
                tension: 0.4
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: true,
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });
}

function createCategoryDistChart(distribution) {
    const ctx = document.getElementById('categoryDistChart');
    if (!ctx) return;
    
    if (charts.categoryDist) charts.categoryDist.destroy();
    
    charts.categoryDist = new Chart(ctx, {
        type: 'pie',
        data: {
            labels: distribution.map(d => d._id),
            datasets: [{
                data: distribution.map(d => d.count),
                backgroundColor: [
                    '#2563eb', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6',
                    '#ec4899', '#06b6d4', '#84cc16'
                ]
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: true
        }
    });
}

// Product Modal
function showAddProductModal() {
    // Reset form
    const form = document.getElementById('product-form');
    form.reset();
    delete form.dataset.productId;
    document.getElementById('product-modal').querySelector('h2').textContent = 'Add Product';
    document.getElementById('product-modal').classList.add('active');
}

function closeModal(modalId) {
    document.getElementById(modalId).classList.remove('active');
}

document.getElementById('product-form')?.addEventListener('submit', async (e) => {
    e.preventDefault();
    const formData = new FormData(e.target);
    const data = Object.fromEntries(formData);
    
    // Convert numeric fields
    data.basePrice = parseFloat(data.basePrice) || 0;
    data.stock = parseInt(data.stock) || 0;
    data.leadTime = parseInt(data.leadTime) || 0;
    
    // Set defaults
    if (!data.currency) data.currency = 'INR';
    if (!data.isActive) data.isActive = true;
    
    const productId = e.target.dataset.productId;
    
    try {
        if (productId) {
            // Update existing product
            await ProductAPI.update(productId, data);
            showNotification('Product updated successfully!', 'success');
            delete e.target.dataset.productId;
            document.getElementById('product-modal').querySelector('h2').textContent = 'Add Product';
        } else {
            // Create new product
            await ProductAPI.create(data);
            showNotification('Product added successfully!', 'success');
        }
        closeModal('product-modal');
        e.target.reset();
        loadProducts();
    } catch (error) {
        console.error('Error saving product:', error);
        showNotification('Error saving product: ' + (error.message || 'Unknown error'), 'error');
    }
});

// Event Listeners
function setupEventListeners() {
    // Recent BOMs: Edit & Delete via delegation (works even when list is re-rendered)
    const recentBomsList = document.getElementById('recent-boms-list');
    if (recentBomsList) {
        recentBomsList.addEventListener('click', (e) => {
            const editBtn = e.target.closest('.recent-bom-edit');
            const deleteBtn = e.target.closest('.recent-bom-delete');
            const rowClick = e.target.closest('.recent-bom-click');
            if (editBtn && editBtn.dataset.bomId) {
                e.stopPropagation();
                editBOM(editBtn.dataset.bomId);
                return;
            }
            if (deleteBtn && deleteBtn.dataset.bomId) {
                e.stopPropagation();
                deleteBOM(deleteBtn.dataset.bomId);
                return;
            }
            if (rowClick) {
                const bomItem = rowClick.closest('.bom-item');
                if (bomItem && bomItem.dataset.bomId) {
                    editBOM(bomItem.dataset.bomId);
                }
            }
        });
    }

    // Component search in BOM builder
    document.getElementById('component-search')?.addEventListener('input', (e) => {
        const searchTerm = e.target.value.toLowerCase();
        const filtered = allProducts.filter(p => 
            p.name.toLowerCase().includes(searchTerm) ||
            p.partNumber.toLowerCase().includes(searchTerm)
        );
        displayAvailableProducts(filtered);
    });
    
    document.getElementById('component-category')?.addEventListener('change', (e) => {
        const category = e.target.value;
        if (category) {
            ProductAPI.getByCategory(category).then(data => {
                displayAvailableProducts(data);
            });
        } else {
            loadAvailableProducts();
        }
    });
}

// Notification System
function showNotification(message, type = 'info') {
    // Create toast notification instead of alert
    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    toast.textContent = message;
    
    // Add styles if not already added
    if (!document.getElementById('toast-styles')) {
        const style = document.createElement('style');
        style.id = 'toast-styles';
        style.textContent = `
            .toast {
                position: fixed;
                top: 20px;
                right: 20px;
                padding: 15px 20px;
                border-radius: 8px;
                color: white;
                font-weight: 500;
                z-index: 10000;
                animation: slideIn 0.3s ease-out;
                box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
                max-width: 400px;
            }
            .toast-success { background: #10b981; }
            .toast-error { background: #ef4444; }
            .toast-info { background: #2563eb; }
            .toast-warning { background: #f59e0b; }
            @keyframes slideIn {
                from {
                    transform: translateX(400px);
                    opacity: 0;
                }
                to {
                    transform: translateX(0);
                    opacity: 1;
                }
            }
        `;
        document.head.appendChild(style);
    }
    
    document.body.appendChild(toast);
    
    // Remove toast after 3 seconds
    setTimeout(() => {
        toast.style.animation = 'slideIn 0.3s ease-out reverse';
        setTimeout(() => toast.remove(), 300);
    }, 3000);
}

// Global functions for onclick handlers
window.showPage = showPage;
window.loadProducts = loadProducts;
window.addToBOM = addToBOM;
window.removeFromBOM = removeFromBOM;
window.updateBOMQuantity = updateBOMQuantity;
window.saveBOM = saveBOM;
window.optimizeBOM = optimizeBOM;
window.runOptimization = runOptimization;
window.applyOptimization = applyOptimization;
window.getAISuggestions = getAISuggestions;
window.addToBOMFromAI = addToBOMFromAI;
window.restoreVersion = restoreVersion;
window.showAddProductModal = showAddProductModal;
window.closeModal = closeModal;
window.loadBOMDetails = (id) => editBOM(id);
window.editBOM = editBOM;
window.deleteBOM = deleteBOM;
window.createNewBOM = createNewBOM;
