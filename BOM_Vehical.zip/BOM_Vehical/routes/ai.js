const express = require('express');
const router = express.Router();
const Product = require('../models/Product');
const { getAIRecommendations } = require('../services/aiEngine');

// Get AI-based component suggestions
router.post('/suggest', async (req, res) => {
  try {
    const { vehicleType, budget, existingComponents = [], requirements = {} } = req.body;
    
    const suggestions = await getAIRecommendations({
      vehicleType,
      budget,
      existingComponents,
      requirements
    });
    
    res.json(suggestions);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Get compatible components
router.post('/compatible', async (req, res) => {
  try {
    const { productId, category } = req.body;
    
    const product = await Product.findById(productId);
    if (!product) {
      return res.status(404).json({ error: 'Product not found' });
    }
    
    // Find compatible products
    const compatibleProducts = await Product.find({
      category: category || product.category,
      _id: { $ne: productId },
      isActive: true,
      $or: [
        { compatibility: { $in: product.compatibility } },
        { partNumber: { $regex: product.partNumber.split('-')[0] } }
      ]
    }).limit(10);
    
    res.json({
      product,
      compatible: compatibleProducts
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Smart component matching
router.post('/match', async (req, res) => {
  try {
    const { specifications, category, maxPrice } = req.body;
    
    const query = {
      category,
      isActive: true
    };
    
    if (maxPrice) {
      query.basePrice = { $lte: maxPrice };
    }
    
    const products = await Product.find(query);
    
    // Score products based on specifications match
    const scoredProducts = products.map(product => {
      let score = 0;
      const matches = {};
      
      if (specifications) {
        Object.keys(specifications).forEach(key => {
          if (product.specifications[key]) {
            const productValue = product.specifications[key];
            const requiredValue = specifications[key];
            
            if (typeof productValue === 'number' && typeof requiredValue === 'number') {
              const difference = Math.abs(productValue - requiredValue);
              const percentage = Math.max(0, 100 - (difference / requiredValue) * 100);
              score += percentage;
              matches[key] = percentage;
            } else if (productValue === requiredValue) {
              score += 100;
              matches[key] = 100;
            }
          }
        });
      }
      
      return {
        product,
        score: score / Object.keys(specifications || {}).length,
        matches
      };
    });
    
    scoredProducts.sort((a, b) => b.score - a.score);
    
    res.json({
      matches: scoredProducts.slice(0, 10)
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;
