// API Configuration
const API_BASE_URL = 'http://localhost:3000/api';

// API Helper Functions
async function apiCall(endpoint, options = {}) {
    try {
        const url = `${API_BASE_URL}${endpoint}`;
        console.log('API Call:', url, options.method || 'GET');
        
        const response = await fetch(url, {
            headers: {
                'Content-Type': 'application/json',
                ...options.headers
            },
            ...options
        });
        
        console.log('API Response status:', response.status, response.statusText);
        
        if (!response.ok) {
            const errorData = await response.json().catch(() => ({ error: response.statusText }));
            console.error('API Error Response:', errorData);
            throw new Error(errorData.error || `API Error: ${response.statusText}`);
        }
        
        const data = await response.json();
        console.log('API Response data:', data);
        return data;
    } catch (error) {
        console.error('API Call Error:', error);
        console.error('Error details:', {
            message: error.message,
            endpoint: endpoint,
            url: `${API_BASE_URL}${endpoint}`
        });
        
        // Return empty data structure instead of throwing to prevent app crash
        if (endpoint.includes('/dashboard')) {
            return {
                statistics: { totalBOMs: 0, activeBOMs: 0, draftBOMs: 0, totalProducts: 0, totalCost: 0 },
                bomsByType: [],
                costByCategory: []
            };
        }
        if (endpoint.includes('/products')) {
            return { products: [], totalPages: 0, currentPage: 1, total: 0 };
        }
        throw error;
    }
}

// Product API
const ProductAPI = {
    getAll: (params = {}) => {
        const query = new URLSearchParams(params).toString();
        const endpoint = query ? `/products?${query}` : '/products';
        console.log('Fetching products from:', `${API_BASE_URL}${endpoint}`);
        return apiCall(endpoint);
    },
    
    getById: (id) => apiCall(`/products/${id}`),
    
    create: (data) => apiCall('/products', {
        method: 'POST',
        body: JSON.stringify(data)
    }),
    
    update: (id, data) => apiCall(`/products/${id}`, {
        method: 'PUT',
        body: JSON.stringify(data)
    }),
    
    delete: (id) => apiCall(`/products/${id}`, {
        method: 'DELETE'
    }),
    
    getByCategory: (category) => apiCall(`/products/category/${category}`)
};

// BOM API
const BOMAPI = {
    getAll: (params = {}) => {
        const query = new URLSearchParams(params).toString();
        return apiCall(`/bom?${query}`);
    },
    
    getById: (id) => apiCall(`/bom/${id}`),
    
    create: (data) => apiCall('/bom', {
        method: 'POST',
        body: JSON.stringify(data)
    }),
    
    update: (id, data) => apiCall(`/bom/${id}`, {
        method: 'PUT',
        body: JSON.stringify(data)
    }),
    
    delete: (id) => apiCall(`/bom/${id}`, {
        method: 'DELETE'
    }),
    
    optimize: (id, targetPrice) => apiCall(`/bom/${id}/optimize`, {
        method: 'POST',
        body: JSON.stringify({ targetPrice })
    }),
    
    predict: (items, vehicleType) => apiCall('/bom/predict', {
        method: 'POST',
        body: JSON.stringify({ items, vehicleType })
    })
};

// AI API
const AIAPI = {
    suggest: (data) => apiCall('/ai/suggest', {
        method: 'POST',
        body: JSON.stringify(data)
    }),
    
    compatible: (productId, category) => apiCall('/ai/compatible', {
        method: 'POST',
        body: JSON.stringify({ productId, category })
    }),
    
    match: (specifications, category, maxPrice) => apiCall('/ai/match', {
        method: 'POST',
        body: JSON.stringify({ specifications, category, maxPrice })
    })
};

// Analytics API
const AnalyticsAPI = {
    getDashboard: () => apiCall('/analytics/dashboard'),
    
    getTrends: (days = 30) => apiCall(`/analytics/trends?days=${days}`),
    
    getCategories: () => apiCall('/analytics/categories')
};

// Version API
const VersionAPI = {
    getByBOM: (bomId) => apiCall(`/version/bom/${bomId}`),
    
    getById: (id) => apiCall(`/version/${id}`),
    
    compare: (version1Id, version2Id) => apiCall(`/version/compare/${version1Id}/${version2Id}`),
    
    restore: (versionId) => apiCall(`/version/restore/${versionId}`, {
        method: 'POST'
    })
};
