const mongoose = require('mongoose');

const versionSchema = new mongoose.Schema({
  bomId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'BOM',
    required: true
  },
  versionNumber: {
    type: Number,
    required: true
  },
  changes: {
    type: String,
    default: ''
  },
  items: [{
    productId: mongoose.Schema.Types.ObjectId,
    quantity: Number,
    unitPrice: Number,
    totalPrice: Number,
    action: {
      type: String,
      enum: ['added', 'removed', 'modified'],
      default: 'modified'
    }
  }],
  totalCost: {
    type: Number,
    required: true
  },
  costDifference: {
    type: Number,
    default: 0
  },
  createdBy: {
    type: String,
    default: 'System'
  },
  createdAt: {
    type: Date,
    default: Date.now
  }
});

versionSchema.index({ bomId: 1, versionNumber: -1 });

module.exports = mongoose.model('Version', versionSchema);
