const Product = require('../models/Product');

// Calculate total cost of BOM items
async function calculateCost(items, vehicleType = 'E-Scooter') {
  let totalCost = 0;
  let breakdown = [];
  
  for (let item of items) {
    const product = await Product.findById(item.productId);
    if (product) {
      const unitPrice = product.basePrice;
      const itemTotal = unitPrice * item.quantity;
      totalCost += itemTotal;
      
      breakdown.push({
        productId: item.productId,
        productName: product.name,
        category: product.category,
        quantity: item.quantity,
        unitPrice,
        totalPrice: itemTotal
      });
    }
  }
  
  // Add vehicle type multiplier
  const multipliers = {
    'E-Scooter': 1.0,
    'E-Bike': 1.5,
    'E-Car': 3.0,
    'E-Bus': 10.0,
    'E-Truck': 8.0,
    'Other': 1.0
  };
  
  const adjustedCost = totalCost * (multipliers[vehicleType] || 1.0);
  
  return {
    baseCost: totalCost,
    adjustedCost,
    vehicleType,
    breakdown,
    estimatedWeight: calculateWeight(breakdown),
    estimatedRange: estimateRange(breakdown, vehicleType)
  };
}

// Optimize BOM to meet target price
async function optimizeBOM(bom, targetPrice) {
  const currentCost = bom.totalCost;
  const savingsNeeded = currentCost - targetPrice;
  
  if (savingsNeeded <= 0) {
    return {
      optimized: false,
      message: 'BOM already meets target price',
      bom
    };
  }
  
  // Find alternative products with lower prices
  const optimizedItems = [];
  let totalSavings = 0;
  
  for (let item of bom.items) {
    const product = await Product.findById(item.productId);
    if (product) {
      // Find cheaper alternatives in same category
      const alternatives = await Product.find({
        category: product.category,
        basePrice: { $lt: product.basePrice },
        isActive: true
      }).sort({ basePrice: 1 }).limit(3);
      
      if (alternatives.length > 0 && totalSavings < savingsNeeded) {
        const alternative = alternatives[0];
        const savings = (product.basePrice - alternative.basePrice) * item.quantity;
        optimizedItems.push({
          original: {
            productId: product._id,
            name: product.name,
            price: product.basePrice
          },
          alternative: {
            productId: alternative._id,
            name: alternative.name,
            price: alternative.basePrice
          },
          quantity: item.quantity,
          savings
        });
        totalSavings += savings;
      } else {
        optimizedItems.push({
          original: {
            productId: product._id,
            name: product.name,
            price: product.basePrice
          },
          alternative: null,
          quantity: item.quantity,
          savings: 0
        });
      }
    }
  }
  
  return {
    optimized: totalSavings > 0,
    originalCost: currentCost,
    optimizedCost: currentCost - totalSavings,
    savings: totalSavings,
    targetPrice,
    recommendations: optimizedItems,
    message: totalSavings >= savingsNeeded 
      ? 'Target price achievable' 
      : `Can save ₹${totalSavings.toFixed(2)}, need ₹${(savingsNeeded - totalSavings).toFixed(2)} more`
  };
}

// Calculate estimated weight
function calculateWeight(breakdown) {
  const weights = breakdown.map(item => {
    // Estimate based on category (in kg)
    const categoryWeights = {
      'Battery': 15,
      'Motor': 8,
      'Controller': 2,
      'Charger': 1,
      'Wiring': 0.5,
      'Frame': 20,
      'Suspension': 5,
      'Brakes': 3,
      'Electronics': 1,
      'Other': 2
    };
    return (categoryWeights[item.category] || 2) * item.quantity;
  });
  
  return weights.reduce((sum, w) => sum + w, 0);
}

// Estimate range based on components
function estimateRange(breakdown, vehicleType) {
  const batteryItem = breakdown.find(item => item.category === 'Battery');
  if (!batteryItem) return 0;
  
  // Base range calculation (km)
  const baseRanges = {
    'E-Scooter': 60,
    'E-Bike': 80,
    'E-Car': 150,
    'E-Bus': 200,
    'E-Truck': 150,
    'Other': 50
  };
  
  const baseRange = baseRanges[vehicleType] || 50;
  const batteryMultiplier = batteryItem.quantity * 1.2;
  
  return Math.round(baseRange * batteryMultiplier);
}

module.exports = {
  calculateCost,
  optimizeBOM,
  calculateWeight,
  estimateRange
};
