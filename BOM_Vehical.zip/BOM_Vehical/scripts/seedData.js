// Sample Data Seeder for BOM Vehicle System
const mongoose = require('mongoose');
const Product = require('../models/Product');
require('dotenv').config();

const sampleProducts = [
    // Battery Products
    {
        name: 'Lithium-Ion Battery Pack 48V 20Ah',
        category: 'Battery',
        partNumber: 'BAT-LI48-20AH',
        description: 'High capacity lithium-ion battery pack for electric vehicles',
        specifications: {
            voltage: 48,
            capacity: 20,
            weight: 15,
            material: 'Lithium-Ion'
        },
        basePrice: 25000,
        supplier: 'BatteryTech India',
        stock: 50,
        leadTime: 7,
        compatibility: ['E-Scooter', 'E-Bike'],
        tags: ['lithium', 'high-capacity', '48v']
    },
    {
        name: 'Lithium-Ion Battery Pack 72V 30Ah',
        category: 'Battery',
        partNumber: 'BAT-LI72-30AH',
        description: 'Premium battery pack for high-performance vehicles',
        specifications: {
            voltage: 72,
            capacity: 30,
            weight: 22,
            material: 'Lithium-Ion'
        },
        basePrice: 45000,
        supplier: 'BatteryTech India',
        stock: 30,
        leadTime: 10,
        compatibility: ['E-Car', 'E-Bus', 'E-Truck'],
        tags: ['lithium', 'premium', '72v']
    },
    {
        name: 'Lithium-Ion Battery Pack 96V 50Ah',
        category: 'Battery',
        partNumber: 'BAT-LI96-50AH',
        description: 'Heavy-duty battery pack for electric trucks',
        specifications: {
            voltage: 96,
            capacity: 50,
            weight: 35,
            material: 'Lithium-Ion'
        },
        basePrice: 75000,
        supplier: 'BatteryTech India',
        stock: 15,
        leadTime: 14,
        compatibility: ['E-Truck'],
        tags: ['lithium', 'heavy-duty', '96v', 'truck']
    },
    
    // Motor Products
    {
        name: 'BLDC Motor 1000W 48V',
        category: 'Motor',
        partNumber: 'MOT-BLDC-1000W',
        description: 'Brushless DC motor for electric scooters',
        specifications: {
            power: 1000,
            voltage: 48,
            current: 20,
            weight: 8,
            material: 'Copper Windings'
        },
        basePrice: 12000,
        supplier: 'MotorWorks Pvt Ltd',
        stock: 100,
        leadTime: 5,
        compatibility: ['E-Scooter', 'E-Bike'],
        tags: ['bldc', '1000w', '48v']
    },
    {
        name: 'BLDC Motor 3000W 72V',
        category: 'Motor',
        partNumber: 'MOT-BLDC-3000W',
        description: 'High-power motor for electric cars',
        specifications: {
            power: 3000,
            voltage: 72,
            current: 42,
            weight: 25,
            material: 'Copper Windings'
        },
        basePrice: 35000,
        supplier: 'MotorWorks Pvt Ltd',
        stock: 40,
        leadTime: 14,
        compatibility: ['E-Car', 'E-Bus'],
        tags: ['bldc', '3000w', '72v']
    },
    
    // Controller Products
    {
        name: 'Motor Controller 48V 30A',
        category: 'Controller',
        partNumber: 'CTRL-48V-30A',
        description: 'Smart controller with regenerative braking',
        specifications: {
            voltage: 48,
            current: 30,
            weight: 2,
            material: 'Aluminum'
        },
        basePrice: 4500,
        supplier: 'ElectroControl Systems',
        stock: 150,
        leadTime: 3,
        compatibility: ['E-Scooter', 'E-Bike'],
        tags: ['controller', '48v', 'regenerative']
    },
    {
        name: 'Motor Controller 72V 50A',
        category: 'Controller',
        partNumber: 'CTRL-72V-50A',
        description: 'Advanced controller for high-performance vehicles',
        specifications: {
            voltage: 72,
            current: 50,
            weight: 3.5,
            material: 'Aluminum'
        },
        basePrice: 8500,
        supplier: 'ElectroControl Systems',
        stock: 60,
        leadTime: 7,
        compatibility: ['E-Car', 'E-Bus', 'E-Truck'],
        tags: ['controller', '72v', 'advanced']
    },
    {
        name: 'Motor Controller 96V 80A',
        category: 'Controller',
        partNumber: 'CTRL-96V-80A',
        description: 'Heavy-duty controller for electric trucks',
        specifications: {
            voltage: 96,
            current: 80,
            weight: 5,
            material: 'Aluminum'
        },
        basePrice: 15000,
        supplier: 'ElectroControl Systems',
        stock: 25,
        leadTime: 10,
        compatibility: ['E-Truck'],
        tags: ['controller', '96v', 'heavy-duty', 'truck']
    },
    
    // Charger Products
    {
        name: 'Fast Charger 48V 5A',
        category: 'Charger',
        partNumber: 'CHG-48V-5A',
        description: 'Fast charging solution for 48V batteries',
        specifications: {
            voltage: 48,
            current: 5,
            weight: 1,
            material: 'Plastic'
        },
        basePrice: 2500,
        supplier: 'ChargeTech India',
        stock: 200,
        leadTime: 2,
        compatibility: ['E-Scooter', 'E-Bike'],
        tags: ['charger', 'fast-charge', '48v']
    },
    {
        name: 'Fast Charger 72V 10A',
        category: 'Charger',
        partNumber: 'CHG-72V-10A',
        description: 'High-power charger for large battery packs',
        specifications: {
            voltage: 72,
            current: 10,
            weight: 2.5,
            material: 'Metal'
        },
        basePrice: 5500,
        supplier: 'ChargeTech India',
        stock: 80,
        leadTime: 5,
        compatibility: ['E-Car', 'E-Bus'],
        tags: ['charger', 'fast-charge', '72v']
    },
    
    // Wiring Products
    {
        name: 'High-Grade Wiring Harness',
        category: 'Wiring',
        partNumber: 'WRG-HARNESS-01',
        description: 'Complete wiring harness for electric vehicle',
        specifications: {
            weight: 0.5,
            material: 'Copper',
            length: 10
        },
        basePrice: 1500,
        supplier: 'WireTech Solutions',
        stock: 300,
        leadTime: 2,
        compatibility: ['E-Scooter', 'E-Bike', 'E-Car', 'E-Truck'],
        tags: ['wiring', 'harness', 'complete']
    },
    
    // Frame Products
    {
        name: 'Aluminum Frame E-Scooter',
        category: 'Frame',
        partNumber: 'FRM-AL-SCOOTER',
        description: 'Lightweight aluminum frame for electric scooter',
        specifications: {
            weight: 20,
            material: 'Aluminum Alloy',
            dimensions: '1200x600x1100mm'
        },
        basePrice: 8000,
        supplier: 'FrameWorks India',
        stock: 50,
        leadTime: 10,
        compatibility: ['E-Scooter'],
        tags: ['frame', 'aluminum', 'lightweight']
    },
    {
        name: 'Steel Frame E-Car',
        category: 'Frame',
        partNumber: 'FRM-STEEL-CAR',
        description: 'Robust steel frame for electric car',
        specifications: {
            weight: 150,
            material: 'Steel',
            dimensions: '4000x1800x1500mm'
        },
        basePrice: 45000,
        supplier: 'FrameWorks India',
        stock: 20,
        leadTime: 21,
        compatibility: ['E-Car'],
        tags: ['frame', 'steel', 'robust']
    },
    
    // Suspension Products
    {
        name: 'Front Suspension Fork',
        category: 'Suspension',
        partNumber: 'SUS-FRONT-FORK',
        description: 'Hydraulic front suspension fork',
        specifications: {
            weight: 5,
            material: 'Steel/Aluminum'
        },
        basePrice: 3500,
        supplier: 'SuspensionPro',
        stock: 100,
        leadTime: 7,
        compatibility: ['E-Scooter', 'E-Bike'],
        tags: ['suspension', 'front', 'hydraulic']
    },
    {
        name: 'Heavy-Duty Suspension System',
        category: 'Suspension',
        partNumber: 'SUS-HEAVY-DUTY',
        description: 'Heavy-duty suspension for trucks',
        specifications: {
            weight: 25,
            material: 'Steel/Alloy'
        },
        basePrice: 25000,
        supplier: 'SuspensionPro',
        stock: 30,
        leadTime: 14,
        compatibility: ['E-Truck'],
        tags: ['suspension', 'heavy-duty', 'truck']
    },
    
    // Brakes Products
    {
        name: 'Disc Brake Set Front & Rear',
        category: 'Brakes',
        partNumber: 'BRK-DISC-SET',
        description: 'Complete disc brake system',
        specifications: {
            weight: 3,
            material: 'Steel'
        },
        basePrice: 2800,
        supplier: 'BrakeTech India',
        stock: 150,
        leadTime: 5,
        compatibility: ['E-Scooter', 'E-Bike'],
        tags: ['brakes', 'disc', 'complete']
    },
    
    // Electronics Products
    {
        name: 'Battery Management System (BMS)',
        category: 'Electronics',
        partNumber: 'ELEC-BMS-48V',
        description: 'Smart BMS for battery protection',
        specifications: {
            voltage: 48,
            weight: 0.5,
            material: 'PCB'
        },
        basePrice: 3200,
        supplier: 'ElectroTech Systems',
        stock: 200,
        leadTime: 3,
        compatibility: ['E-Scooter', 'E-Bike'],
        tags: ['bms', 'protection', 'smart']
    },
    {
        name: 'Digital Display Dashboard',
        category: 'Electronics',
        partNumber: 'ELEC-DASHBOARD',
        description: 'LCD dashboard with speed, battery, and range display',
        specifications: {
            weight: 0.3,
            material: 'Plastic/LCD'
        },
        basePrice: 1800,
        supplier: 'ElectroTech Systems',
        stock: 250,
        leadTime: 2,
        compatibility: ['E-Scooter', 'E-Bike', 'E-Car', 'E-Truck'],
        tags: ['dashboard', 'display', 'lcd']
    },
    {
        name: 'Battery Management System (BMS) 96V',
        category: 'Electronics',
        partNumber: 'ELEC-BMS-96V',
        description: 'Advanced BMS for truck battery systems',
        specifications: {
            voltage: 96,
            weight: 1.5,
            material: 'PCB'
        },
        basePrice: 8500,
        supplier: 'ElectroTech Systems',
        stock: 40,
        leadTime: 7,
        compatibility: ['E-Truck'],
        tags: ['bms', 'protection', '96v', 'truck']
    },
    {
        name: 'Truck Instrument Cluster',
        category: 'Electronics',
        partNumber: 'ELEC-CLUSTER-TRUCK',
        description: 'Professional instrument cluster for electric trucks',
        specifications: {
            weight: 1.2,
            material: 'Plastic/LCD'
        },
        basePrice: 12000,
        supplier: 'ElectroTech Systems',
        stock: 25,
        leadTime: 10,
        compatibility: ['E-Truck'],
        tags: ['dashboard', 'cluster', 'truck', 'professional']
    }
];

async function seedDatabase() {
    try {
        // Connect to MongoDB
        await mongoose.connect(process.env.MONGODB_URI || 'mongodb://localhost:27017/bom_vehicle', {
            useNewUrlParser: true,
            useUnifiedTopology: true,
        });
        
        console.log('✅ Connected to MongoDB');
        
        // Clear existing products
        await Product.deleteMany({});
        console.log('✅ Cleared existing products');
        
        // Insert sample products
        const products = await Product.insertMany(sampleProducts);
        console.log(`✅ Inserted ${products.length} products`);
        
        // Display summary
        console.log('\n📊 Product Summary:');
        const categories = await Product.aggregate([
            { $group: { _id: '$category', count: { $sum: 1 } } },
            { $sort: { _id: 1 } }
        ]);
        
        categories.forEach(cat => {
            console.log(`   ${cat._id}: ${cat.count} products`);
        });
        
        console.log('\n✅ Database seeding completed successfully!');
        process.exit(0);
    } catch (error) {
        console.error('❌ Error seeding database:', error);
        process.exit(1);
    }
}

// Run seeder
seedDatabase();
