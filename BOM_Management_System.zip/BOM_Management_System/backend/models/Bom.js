const mongoose = require("mongoose");

const BomSchema = new mongoose.Schema({
  productId: {
    type: String,
    required: true,
    trim: true
  },
  components: [{
    componentName: {
      type: String,
      required: true,
      trim: true
    },
    quantity: {
      type: Number,
      required: true,
      min: 0
    },
    unitCost: {
      type: Number,
      required: true,
      min: 0
    }
  }],
  laborCost: {
    type: Number,
    default: 0,
    min: 0
  },
  overhead: {
    type: Number,
    default: 0,
    min: 0
  },
  totalCost: {
    type: Number,
    required: true,
    min: 0
  },
  version: {
    type: String,
    default: "v1.0"
  }
}, {
  timestamps: true
});

module.exports = mongoose.model("Bom", BomSchema);
