const BOM_API = "http://localhost:5000/api/bom";
const PRODUCT_API = "http://localhost:5000/api/products";

let components = [];

// Load Products in dropdown
function loadProductsDropdown() {
  fetch(PRODUCT_API)
    .then(res => {
      if (!res.ok) {
        throw new Error(`HTTP error! status: ${res.status}`);
      }
      return res.json();
    })
    .then(data => {
      const bomProductSelect = document.getElementById("bomProduct");
      const historyProductSelect = document.getElementById("historyProduct");
      
      if (bomProductSelect) {
        let options = `<option value="">Select Product</option>`;
        if (data && data.length > 0) {
          data.forEach(p => {
            options += `<option value="${p.productId}">${p.name}</option>`;
          });
        }
        bomProductSelect.innerHTML = options;
      }
      
      if (historyProductSelect) {
        let historyOptions = `<option value="">Select Product</option>`;
        if (data && data.length > 0) {
          data.forEach(p => {
            historyOptions += `<option value="${p.productId}">${p.name}</option>`;
          });
        }
        historyProductSelect.innerHTML = historyOptions;
      }
    })
    .catch(err => {
      console.error("Error loading products:", err);
      const bomProductSelect = document.getElementById("bomProduct");
      if (bomProductSelect) {
        bomProductSelect.innerHTML = `<option value="">Error loading products</option>`;
      }
    });
}

// Load products on page load
window.addEventListener("DOMContentLoaded", loadProductsDropdown);

// Add Component Row
function addComponentRow() {
  const componentRows = document.getElementById("componentRows");
  if (!componentRows) {
    console.error("componentRows element not found");
    return;
  }

  const row = document.createElement("tr");
  row.innerHTML = `
    <td><input type="text" placeholder="Component name" class="component-name"></td>
    <td><input type="number" value="1" min="0" class="component-qty" onchange="calculateTotal()"></td>
    <td><input type="number" value="0" min="0" step="0.01" class="component-cost" onchange="calculateTotal()"></td>
    <td><button class="btn btn-danger" onclick="this.parentElement.parentElement.remove(); calculateTotal();">X</button></td>
  `;
  componentRows.appendChild(row);
}

// Calculate Total Cost
function calculateTotal() {
  const rows = document.querySelectorAll("#componentRows tr");
  let componentTotal = 0;

  rows.forEach(r => {
    const qty = parseFloat(r.querySelector(".component-qty")?.value || 0);
    const cost = parseFloat(r.querySelector(".component-cost")?.value || 0);
    componentTotal += qty * cost;
  });

  const laborCost = parseFloat(document.getElementById("laborCost")?.value || 0);
  const overhead = parseFloat(document.getElementById("overhead")?.value || 0);
  const totalCost = componentTotal + laborCost + overhead;

  const totalCostElement = document.getElementById("totalCost");
  if (totalCostElement) {
    totalCostElement.innerText = totalCost.toFixed(2);
  }
}

// Save BOM
function saveBOM() {
  const productId = document.getElementById("bomProduct")?.value;
  
  if (!productId) {
    alert("Please select a product");
    return;
  }

  const rows = document.querySelectorAll("#componentRows tr");
  components = [];

  rows.forEach(r => {
    const nameInput = r.querySelector(".component-name");
    const qtyInput = r.querySelector(".component-qty");
    const costInput = r.querySelector(".component-cost");
    
    const componentName = nameInput?.value.trim();
    const quantity = Number(qtyInput?.value || 0);
    const unitCost = Number(costInput?.value || 0);

    if (componentName && quantity > 0) {
      components.push({
        componentName,
        quantity,
        unitCost
      });
    }
  });

  if (components.length === 0) {
    alert("Please add at least one component");
    return;
  }

  const data = {
    productId,
    components,
    laborCost: Number(document.getElementById("laborCost")?.value || 0),
    overhead: Number(document.getElementById("overhead")?.value || 0),
    version: "v1.0"
  };

  fetch(`${BOM_API}/create`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(data)
  })
  .then(async res => {
    const data = await res.json();
    if (!res.ok) {
      throw new Error(data.error || `HTTP error! status: ${res.status}`);
    }
    return data;
  })
  .then(result => {
    const totalCostElement = document.getElementById("totalCost");
    if (totalCostElement && result.totalCost) {
      totalCostElement.innerText = result.totalCost.toFixed(2);
    }
    alert(result.message || "BOM Saved Successfully");
    // Clear form
    document.getElementById("componentRows").innerHTML = "";
    document.getElementById("laborCost").value = "0";
    document.getElementById("overhead").value = "0";
    calculateTotal();
  })
  .catch(err => {
    console.error("Error saving BOM:", err);
    alert("Error saving BOM: " + err.message);
  });
}

function loadHistory() {
  const productId = document.getElementById("historyProduct")?.value;
  
  if (!productId) {
    alert("Please select a product");
    return;
  }

  fetch(`${BOM_API}/history/${productId}`)
    .then(async res => {
      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || `HTTP error! status: ${res.status}`);
      }
      return data;
    })
    .then(data => {
      const historyList = document.getElementById("historyList");
      if (!historyList) {
        console.error("historyList element not found");
        return;
      }

      if (!data || data.length === 0) {
        historyList.innerHTML = "<p>No history found for this product</p>";
        return;
      }

      let html = "";
      data.forEach(b => {
        html += `
          <div class="stat-box">
            <strong>Version:</strong> ${b.version || "N/A"}<br>
            <strong>Total Cost:</strong> ₹${b.totalCost ? b.totalCost.toFixed(2) : "0.00"}<br>
            <small>${b.createdAt ? new Date(b.createdAt).toLocaleString() : "N/A"}</small>
          </div><br>
        `;
      });
      historyList.innerHTML = html;
    })
    .catch(err => {
      console.error("Error loading history:", err);
      const historyList = document.getElementById("historyList");
      if (historyList) {
        historyList.innerHTML = `<p style="color: red;">Error loading history: ${err.message}</p>`;
      }
    });
}

// Add event listeners for labor cost and overhead to update total
window.addEventListener("DOMContentLoaded", () => {
  const laborCostInput = document.getElementById("laborCost");
  const overheadInput = document.getElementById("overhead");
  
  if (laborCostInput) {
    laborCostInput.addEventListener("input", calculateTotal);
  }
  if (overheadInput) {
    overheadInput.addEventListener("input", calculateTotal);
  }
});
