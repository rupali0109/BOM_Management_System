const express = require("express");
const Bom = require("../models/Bom");
const router = express.Router();

// Get all BOMs
router.get("/", async (req, res) => {
  try {
    const boms = await Bom.find();
    res.json(boms);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Create BOM
router.post("/create", async (req, res) => {
  try {
    const { productId, components, laborCost, overhead, version } = req.body;

    // Validation
    if (!productId || productId.trim() === "") {
      return res.status(400).json({ error: "Product ID is required" });
    }
    
    if (!Array.isArray(components) || components.length === 0) {
      return res.status(400).json({ error: "Components array is required and must not be empty" });
    }
    
    // Validate components
    for (let i = 0; i < components.length; i++) {
      const c = components[i];
      if (!c.componentName || c.componentName.trim() === "") {
        return res.status(400).json({ error: `Component ${i + 1}: Component name is required` });
      }
      if (!c.quantity || c.quantity <= 0) {
        return res.status(400).json({ error: `Component ${i + 1}: Quantity must be greater than 0` });
      }
      if (c.unitCost === undefined || c.unitCost === null || c.unitCost < 0) {
        return res.status(400).json({ error: `Component ${i + 1}: Unit cost must be a valid positive number` });
      }
    }
    
    if (laborCost === undefined || laborCost === null || isNaN(laborCost)) {
      return res.status(400).json({ error: "Labor cost is required and must be a valid number" });
    }
    
    if (overhead === undefined || overhead === null || isNaN(overhead)) {
      return res.status(400).json({ error: "Overhead is required and must be a valid number" });
    }

    let componentTotal = 0;
    components.forEach(c => {
      const quantity = parseFloat(c.quantity) || 0;
      const unitCost = parseFloat(c.unitCost) || 0;
      componentTotal += quantity * unitCost;
    });

    const totalCost = componentTotal + parseFloat(laborCost || 0) + parseFloat(overhead || 0);

    const bom = new Bom({
      productId: productId.trim(),
      components: components.map(c => ({
        componentName: c.componentName.trim(),
        quantity: parseFloat(c.quantity),
        unitCost: parseFloat(c.unitCost)
      })),
      laborCost: parseFloat(laborCost),
      overhead: parseFloat(overhead),
      totalCost: parseFloat(totalCost.toFixed(2)),
      version: version || "v1.0"
    });

    await bom.save();
    res.json({ message: "BOM saved successfully", totalCost: bom.totalCost, bom });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Get BOM History by Product
router.get("/history/:productId", async (req, res) => {
  try {
    const history = await Bom.find({ productId: req.params.productId })
                             .sort({ createdAt: -1 });
    res.json(history);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;
