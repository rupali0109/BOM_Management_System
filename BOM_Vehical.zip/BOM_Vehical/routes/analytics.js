const express = require('express');
const router = express.Router();
const BOM = require('../models/BOM');
const Product = require('../models/Product');
const Version = require('../models/Version');

// Get dashboard statistics
router.get('/dashboard', async (req, res) => {
  try {
    const totalBOMs = await BOM.countDocuments().catch(() => 0);
    const activeBOMs = await BOM.countDocuments({ status: 'Active' }).catch(() => 0);
    const totalProducts = await Product.countDocuments({ isActive: true }).catch(() => 0);
    
    let totalCost = 0;
    try {
      const costResult = await BOM.aggregate([
        { $group: { _id: null, total: { $sum: '$totalCost' } } }
      ]);
      totalCost = costResult[0]?.total || 0;
    } catch (err) {
      console.error('Error calculating total cost:', err);
    }
    
    let bomsByType = [];
    try {
      bomsByType = await BOM.aggregate([
        { $group: { _id: '$vehicleType', count: { $sum: 1 } } }
      ]);
    } catch (err) {
      console.error('Error getting BOMs by type:', err);
    }
    
    let costByCategory = [];
    try {
      // First check if there are any BOMs with items
      const bomsWithItems = await BOM.countDocuments({ 'items.0': { $exists: true } });
      
      if (bomsWithItems > 0) {
        // Use standard lookup syntax
        costByCategory = await BOM.aggregate([
          // Match only BOMs that have items
          { $match: { 'items.0': { $exists: true } } },
          { $unwind: '$items' },
          // Lookup product information
          {
            $lookup: {
              from: 'products',
              localField: 'items.productId',
              foreignField: '_id',
              as: 'product'
            }
          },
          // Unwind product array
          { $unwind: { path: '$product', preserveNullAndEmptyArrays: false } },
          // Group by category and sum costs
          { 
            $group: { 
              _id: '$product.category', 
              totalCost: { $sum: { $ifNull: ['$items.totalPrice', 0] } },
              itemCount: { $sum: 1 }
            } 
          },
          { $sort: { totalCost: -1 } }
        ]);
      }
      
      // If still empty or no BOMs, show product-based categories as fallback
      if (costByCategory.length === 0) {
        console.log('No BOMs with items found, using product categories as fallback');
        // Get all products and their categories with total base price
        const productCategories = await Product.aggregate([
          { $match: { isActive: true } },
          { $group: { 
            _id: '$category', 
            totalCost: { $sum: '$basePrice' },
            productCount: { $sum: 1 }
          } },
          { $sort: { totalCost: -1 } }
        ]);
        
        // Use product categories as fallback
        if (productCategories.length > 0) {
          costByCategory = productCategories.map(cat => ({
            _id: cat._id,
            totalCost: cat.totalCost,
            itemCount: cat.productCount
          }));
        }
      }
    } catch (err) {
      console.error('Error getting cost by category:', err);
      // Fallback to product-based categories
      try {
        const productCategories = await Product.aggregate([
          { $match: { isActive: true } },
          { $group: { 
            _id: '$category', 
            totalCost: { $sum: '$basePrice' },
            productCount: { $sum: 1 }
          } },
          { $sort: { totalCost: -1 } }
        ]);
        costByCategory = productCategories.map(cat => ({
          _id: cat._id,
          totalCost: cat.totalCost
        }));
      } catch (fallbackErr) {
        console.error('Fallback also failed:', fallbackErr);
        costByCategory = [];
      }
    }
    
    res.json({
      statistics: {
        totalBOMs: totalBOMs || 0,
        activeBOMs: activeBOMs || 0,
        draftBOMs: (totalBOMs || 0) - (activeBOMs || 0),
        totalProducts: totalProducts || 0,
        totalCost: totalCost || 0
      },
      bomsByType: bomsByType || [],
      costByCategory: costByCategory || []
    });
  } catch (error) {
    console.error('Error fetching dashboard data:', error);
    res.status(500).json({ error: error.message });
  }
});

// Get cost trends
router.get('/trends', async (req, res) => {
  try {
    const { days = 30 } = req.query;
    const startDate = new Date();
    startDate.setDate(startDate.getDate() - parseInt(days));
    
    const versions = await Version.find({
      createdAt: { $gte: startDate }
    }).sort({ createdAt: 1 });
    
    const trends = versions.map(v => ({
      date: v.createdAt,
      cost: v.totalCost,
      version: v.versionNumber,
      costDifference: v.costDifference
    }));
    
    res.json({ trends });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Get category distribution
router.get('/categories', async (req, res) => {
  try {
    const distribution = await Product.aggregate([
      { $match: { isActive: true } },
      { $group: { _id: '$category', count: { $sum: 1 }, avgPrice: { $avg: '$basePrice' } } },
      { $sort: { count: -1 } }
    ]);
    
    res.json({ distribution });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;
