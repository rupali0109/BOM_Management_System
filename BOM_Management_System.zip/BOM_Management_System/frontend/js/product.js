const API_URL = "http://localhost:5000/api/products";

// Add Product
function addProduct() {
  const productIdInput = document.getElementById("productId");
  const nameInput = document.getElementById("name");
  const categoryInput = document.getElementById("category");
  const statusInput = document.getElementById("status");
  
  if (!productIdInput || !nameInput) {
    alert("Form elements not found. Please refresh the page.");
    return;
  }
  
  const product = {
    productId: productIdInput.value.trim(),
    name: nameInput.value.trim(),
    category: categoryInput ? categoryInput.value.trim() : "",
    status: statusInput ? statusInput.value : "Active"
  };

  // Validation - only name is required
  if (!product.name || product.name.trim() === "") {
    alert("Product Name is required");
    nameInput.focus();
    return;
  }

  // Show loading state
  const saveButton = document.getElementById("saveProductBtn");
  const originalText = saveButton ? saveButton.textContent : "Save Product";
  if (saveButton) {
    saveButton.disabled = true;
    saveButton.textContent = "Saving...";
  }

  fetch(`${API_URL}/add`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(product)
  })
  .then(async res => {
    const data = await res.json();
    if (!res.ok) {
      // Handle error response
      throw new Error(data.error || `HTTP error! status: ${res.status}`);
    }
    return data;
  })
  .then(data => {
    alert(data.message || "Product added successfully");
    // Clear form and hide it
    productIdInput.value = "";
    nameInput.value = "";
    if (categoryInput) categoryInput.value = "";
    if (statusInput) statusInput.value = "Active";
    
    const form = document.getElementById("productForm");
    if (form) {
      form.style.display = "none";
      // Reset form title and button
      const formTitle = document.getElementById("formTitle");
      if (formTitle) formTitle.textContent = "Add Product";
      if (saveButton) {
        saveButton.textContent = "Save Product";
        saveButton.setAttribute("onclick", "addProduct()");
        saveButton.disabled = false;
      }
    }
    loadProducts();
    // Refresh dashboard stats
    if (typeof loadDashboardStats === "function") {
      loadDashboardStats();
    }
  })
  .catch(err => {
    console.error("Error adding product:", err);
    alert("Error adding product: " + err.message);
    // Reset button
    if (saveButton) {
      saveButton.disabled = false;
      saveButton.textContent = originalText;
    }
  });
}

// Load Products
function loadProducts() {
  fetch(API_URL)
    .then(res => {
      if (!res.ok) {
        throw new Error(`HTTP error! status: ${res.status}`);
      }
      return res.json();
    })
    .then(data => {
      showListView(data);
      showGridView(data);
    })
    .catch(err => {
      console.error("Error loading products:", err);
      const tableBody = document.getElementById("productTable");
      if (tableBody) {
        tableBody.innerHTML = `<tr><td colspan="5" style="text-align: center; color: red;">Error loading products: ${err.message}</td></tr>`;
      }
    });
}

// List View
function showListView(products) {
  const tableBody = document.getElementById("productTable");
  
  if (!tableBody) {
    console.error("productTable element not found in HTML");
    return;
  }

  if (!products || products.length === 0) {
    tableBody.innerHTML = `<tr><td colspan="5" style="text-align: center;">No products found</td></tr>`;
    return;
  }

  let rows = "";
  products.forEach(p => {
    rows += `
      <tr>
        <td>${p.productId || "N/A"}</td>
        <td>${p.name || "N/A"}</td>
        <td>${p.category || "N/A"}</td>
        <td>${p.status || "Active"}</td>
        <td>
          <button class="btn btn-secondary" onclick="editProduct('${p._id}')">Edit</button>
          <button class="btn btn-danger" onclick="deleteProduct('${p._id}')">Delete</button>
        </td>
      </tr>
    `;
  });
  tableBody.innerHTML = rows;
}

// Grid View
function showGridView(products) {
  const gridContainer = document.getElementById("productGrid");
  
  if (!gridContainer) {
    return;
  }

  if (!products || products.length === 0) {
    gridContainer.innerHTML = "<p style='text-align: center;'>No products found</p>";
    return;
  }

  let cards = "";
  products.forEach(p => {
    cards += `
      <div class="product-card">
        <strong>${p.name || "N/A"}</strong><br>
        Category: ${p.category || "N/A"}<br>
        Status: ${p.status || "Active"}<br><br>
        <button class="btn btn-secondary" onclick="editProduct('${p._id}')">Edit</button>
        <button class="btn btn-danger" onclick="deleteProduct('${p._id}')">Delete</button>
      </div>
    `;
  });
  gridContainer.innerHTML = cards;
}

// Edit Product
function editProduct(id) {
  fetch(`${API_URL}/${id}`)
    .then(res => {
      if (!res.ok) {
        throw new Error(`HTTP error! status: ${res.status}`);
      }
      return res.json();
    })
    .then(product => {
      // Populate form with product data
      document.getElementById("productId").value = product.productId || "";
      document.getElementById("name").value = product.name || "";
      document.getElementById("category").value = product.category || "";
      document.getElementById("status").value = product.status || "Active";
      
      // Show form
      const form = document.getElementById("productForm");
      if (form) {
        form.style.display = "block";
        // Update form title
        document.getElementById("formTitle").textContent = "Edit Product";
        
        // Change button text and onclick
        const saveButton = document.getElementById("saveProductBtn");
        if (saveButton) {
          saveButton.textContent = "Update Product";
          saveButton.setAttribute("onclick", `updateProduct('${id}')`);
        }
      }
      
      // Scroll to form
      form.scrollIntoView({ behavior: "smooth", block: "nearest" });
    })
    .catch(err => {
      console.error("Error loading product:", err);
      alert("Error loading product: " + err.message);
    });
}

// Update Product
function updateProduct(id) {
  const productIdInput = document.getElementById("productId");
  const nameInput = document.getElementById("name");
  const categoryInput = document.getElementById("category");
  const statusInput = document.getElementById("status");
  
  if (!nameInput) {
    alert("Form elements not found. Please refresh the page.");
    return;
  }
  
  const product = {
    productId: productIdInput ? productIdInput.value.trim() : "",
    name: nameInput.value.trim(),
    category: categoryInput ? categoryInput.value.trim() : "",
    status: statusInput ? statusInput.value : "Active"
  };

  if (!product.name || product.name.trim() === "") {
    alert("Product name is required");
    nameInput.focus();
    return;
  }

  // Show loading state
  const saveButton = document.getElementById("saveProductBtn");
  const originalText = saveButton ? saveButton.textContent : "Update Product";
  if (saveButton) {
    saveButton.disabled = true;
    saveButton.textContent = "Updating...";
  }

  fetch(`${API_URL}/${id}`, {
    method: "PUT",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(product)
  })
  .then(async res => {
    const data = await res.json();
    if (!res.ok) {
      throw new Error(data.error || `HTTP error! status: ${res.status}`);
    }
    return data;
  })
  .then(data => {
    alert(data.message || "Product updated successfully");
    // Clear form and hide it
    if (productIdInput) productIdInput.value = "";
    if (nameInput) nameInput.value = "";
    if (categoryInput) categoryInput.value = "";
    if (statusInput) statusInput.value = "Active";
    
    const form = document.getElementById("productForm");
    if (form) {
      form.style.display = "none";
      // Reset form title and button
      const formTitle = document.getElementById("formTitle");
      if (formTitle) formTitle.textContent = "Add Product";
      if (saveButton) {
        saveButton.textContent = "Save Product";
        saveButton.setAttribute("onclick", "addProduct()");
        saveButton.disabled = false;
      }
    }
    loadProducts();
    // Refresh dashboard stats
    if (typeof loadDashboardStats === "function") {
      loadDashboardStats();
    }
  })
  .catch(err => {
    console.error("Error updating product:", err);
    alert("Error updating product: " + err.message);
    // Reset button
    if (saveButton) {
      saveButton.disabled = false;
      saveButton.textContent = originalText;
    }
  });
}

// Delete Product
function deleteProduct(id) {
  if (!confirm("Are you sure you want to delete this product?")) {
    return;
  }

  fetch(`${API_URL}/${id}`, {
    method: "DELETE",
    headers: { "Content-Type": "application/json" }
  })
  .then(async res => {
    const data = await res.json();
    if (!res.ok) {
      throw new Error(data.error || `HTTP error! status: ${res.status}`);
    }
    return data;
  })
  .then(data => {
    alert(data.message || "Product deleted successfully");
    loadProducts();
    // Refresh dashboard stats
    if (typeof loadDashboardStats === "function") {
      loadDashboardStats();
    }
  })
  .catch(err => {
    console.error("Error deleting product:", err);
    alert("Error deleting product: " + err.message);
  });
}

// Make addProduct globally accessible
window.addProduct = addProduct;

// Load on page start
window.onload = function() {
  loadProducts();
  // Ensure addProduct is accessible
  if (typeof addProduct === "function") {
    window.addProduct = addProduct;
    console.log("addProduct function is now globally accessible");
  }
};
