const express = require("express");
const Product = require("../models/Product");
const router = express.Router();

// Add Product
router.post("/add", async (req, res) => {
  try {
    const { productId, name, category, status } = req.body;
    
    // Validation
    if (!name || name.trim() === "") {
      return res.status(400).json({ error: "Product name is required" });
    }

    // Generate productId if not provided
    let finalProductId = productId;
    if (!finalProductId || finalProductId.trim() === "") {
      // Generate a product ID based on timestamp and random number
      finalProductId = `PROD-${Date.now()}-${Math.floor(Math.random() * 1000)}`;
    }

    // Check if productId already exists
    const existingProduct = await Product.findOne({ productId: finalProductId });
    if (existingProduct) {
      return res.status(400).json({ error: "Product ID already exists. Please use a different Product ID." });
    }

    const product = new Product({ 
      productId: finalProductId, 
      name: name.trim(), 
      category: category ? category.trim() : "", 
      status: status || "Active" 
    });
    await product.save();
    res.json({ message: "Product added successfully", product });
  } catch (error) {
    // Handle duplicate key error
    if (error.code === 11000) {
      return res.status(400).json({ error: "Product ID already exists. Please use a different Product ID." });
    }
    res.status(500).json({ error: error.message });
  }
});

// Get Products (must be before GET /:id)
router.get("/", async (req, res) => {
  try {
    const products = await Product.find().sort({ createdAt: -1 });
    res.json(products);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Get Single Product by ID (must be after GET /)
router.get("/:id", async (req, res) => {
  try {
    // Check if it's a valid MongoDB ObjectId
    if (!req.params.id.match(/^[0-9a-fA-F]{24}$/)) {
      return res.status(400).json({ error: "Invalid product ID format" });
    }
    
    const product = await Product.findById(req.params.id);
    if (!product) {
      return res.status(404).json({ error: "Product not found" });
    }
    res.json(product);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Update Product
router.put("/:id", async (req, res) => {
  try {
    // Check if it's a valid MongoDB ObjectId
    if (!req.params.id.match(/^[0-9a-fA-F]{24}$/)) {
      return res.status(400).json({ error: "Invalid product ID format" });
    }
    
    const { productId, name, category, status } = req.body;
    
    // Validation
    if (!name || name.trim() === "") {
      return res.status(400).json({ error: "Product name is required" });
    }

    const updateData = {
      name: name.trim(),
      category: category ? category.trim() : "",
      status: status || "Active"
    };
    
    // Only update productId if provided
    if (productId && productId.trim() !== "") {
      updateData.productId = productId.trim();
    }

    const product = await Product.findByIdAndUpdate(
      req.params.id,
      updateData,
      { new: true, runValidators: true }
    );

    if (!product) {
      return res.status(404).json({ error: "Product not found" });
    }

    res.json({ message: "Product updated successfully", product });
  } catch (error) {
    if (error.code === 11000) {
      return res.status(400).json({ error: "Product ID already exists. Please use a different Product ID." });
    }
    res.status(500).json({ error: error.message });
  }
});

// Delete Product
router.delete("/:id", async (req, res) => {
  try {
    // Check if it's a valid MongoDB ObjectId
    if (!req.params.id.match(/^[0-9a-fA-F]{24}$/)) {
      return res.status(400).json({ error: "Invalid product ID format" });
    }
    
    const product = await Product.findByIdAndDelete(req.params.id);
    
    if (!product) {
      return res.status(404).json({ error: "Product not found" });
    }

    res.json({ message: "Product deleted successfully", product });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;
