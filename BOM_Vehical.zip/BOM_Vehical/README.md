# BOM - Electrical Vehicle System

एक professional AI-powered Bill of Materials (BOM) management system electrical vehicles के लिए।

## Features

### ✅ Frontend Features
- **Dashboard** - BOM statistics और visualizations के साथ
- **Product Management** - Complete CRUD operations
- **Dynamic BOM Builder** - Interactive component selection और management
- **AI Suggestions Panel** - Intelligent component recommendations
- **Cost Breakdown** - Detailed cost analysis
- **Version History View** - Complete version tracking
- **Analytics Charts** - Visual data representation

### ✅ Backend Features
- **Product CRUD** - Complete product management API
- **BOM Generation Logic** - Smart BOM creation और management
- **Cost Calculation Engine** - Real-time cost calculations
- **API Integration** - External pricing API support
- **AI Recommendation Engine** - ML-based component suggestions
- **Version Control** - Complete version history management
- **Admin Settings** - System configuration

## Tech Stack

- **Backend**: Node.js, Express.js, MongoDB
- **Frontend**: HTML5, CSS3, Vanilla JavaScript
- **Charts**: Chart.js
- **AI/ML**: Custom recommendation engine
- **API**: RESTful API architecture

## Installation

### Prerequisites
- Node.js (v14 या higher)
- MongoDB (local या MongoDB Atlas)
- npm या yarn

### Setup Steps

1. **Dependencies Install करें:**
```bash
npm install
```

2. **Environment Variables Setup:**
`.env` file में MongoDB connection string update करें:
```
MONGODB_URI=mongodb://localhost:27017/bom_vehicle
PORT=3000
```

3. **MongoDB Start करें:**
```bash
# Windows
mongod

# या MongoDB service को start करें
```

4. **Server Start करें:**
```bash
# Development mode
npm run dev

# Production mode
npm start
```

5. **Browser में खोलें:**
```
http://localhost:3000
```

## Project Structure

```
BOM_Vehical/
├── server.js              # Main server file
├── package.json           # Dependencies
├── .env                   # Environment variables
├── models/                # Database models
│   ├── Product.js
│   ├── BOM.js
│   └── Version.js
├── routes/                # API routes
│   ├── products.js
│   ├── bom.js
│   ├── ai.js
│   ├── analytics.js
│   └── version.js
├── services/              # Business logic
│   ├── costEngine.js
│   └── aiEngine.js
└── public/                # Frontend files
    ├── index.html
    ├── css/
    │   └── style.css
    └── js/
        ├── api.js
        └── app.js
```

## API Endpoints

### Products
- `GET /api/products` - Get all products
- `GET /api/products/:id` - Get product by ID
- `POST /api/products` - Create product
- `PUT /api/products/:id` - Update product
- `DELETE /api/products/:id` - Delete product
- `GET /api/products/category/:category` - Get products by category

### BOM
- `GET /api/bom` - Get all BOMs
- `GET /api/bom/:id` - Get BOM by ID
- `POST /api/bom` - Create BOM
- `PUT /api/bom/:id` - Update BOM
- `DELETE /api/bom/:id` - Delete BOM
- `POST /api/bom/:id/optimize` - Optimize BOM cost
- `POST /api/bom/predict` - Predict BOM cost

### AI
- `POST /api/ai/suggest` - Get AI component suggestions
- `POST /api/ai/compatible` - Find compatible components
- `POST /api/ai/match` - Smart component matching

### Analytics
- `GET /api/analytics/dashboard` - Get dashboard statistics
- `GET /api/analytics/trends` - Get cost trends
- `GET /api/analytics/categories` - Get category distribution

### Version
- `GET /api/version/bom/:bomId` - Get all versions of a BOM
- `GET /api/version/:id` - Get specific version
- `GET /api/version/compare/:v1/:v2` - Compare two versions
- `POST /api/version/restore/:id` - Restore BOM to version

## Usage

### 1. Products Add करें
- "Products" page पर जाएं
- "Add Product" button click करें
- Product details fill करें और save करें

### 2. BOM Create करें
- "BOM Builder" page पर जाएं
- Vehicle type select करें
- Components add करें
- BOM name और description add करें
- Save करें

### 3. AI Suggestions Use करें
- "AI Suggestions" page पर जाएं
- Vehicle type और budget enter करें
- "Get AI Suggestions" click करें
- Suggested components को BOM में add करें

### 4. Version History देखें
- "Version History" page पर जाएं
- BOM select करें
- सभी versions देखें और compare करें
- किसी भी version को restore करें

## Features Details

### AI Component Suggestions
- Vehicle type के based essential components suggest करता है
- Budget constraints को consider करता है
- Compatible alternatives suggest करता है
- Confidence score provide करता है

### Cost Optimization
- Target price set करके optimization कर सकते हैं
- Cheaper alternatives suggest करता है
- Cost savings calculate करता है

### Version Control
- हर BOM change को track करता है
- Version comparison कर सकते हैं
- किसी भी previous version को restore कर सकते हैं

## Future Enhancements

- [ ] User authentication और authorization
- [ ] Real-time pricing API integration
- [ ] Advanced ML models for predictions
- [ ] Export functionality (PDF, Excel)
- [ ] Email notifications
- [ ] Multi-language support
- [ ] Mobile app

## Contributing

यह एक internship project है। Suggestions और improvements welcome हैं!

## License

ISC

## Author

MCA 2nd Year Student - Internship Project

---

**Note**: यह project educational purposes के लिए है। Production use के लिए additional security और optimization की जरूरत होगी।
