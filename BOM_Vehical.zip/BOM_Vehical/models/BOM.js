const mongoose = require('mongoose');

const bomItemSchema = new mongoose.Schema({
  productId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Product',
    required: true
  },
  quantity: {
    type: Number,
    required: true,
    min: 1
  },
  unitPrice: {
    type: Number,
    required: true,
    min: 0
  },
  totalPrice: {
    type: Number,
    required: true,
    min: 0
  },
  notes: {
    type: String,
    default: ''
  }
});

const bomSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true,
    trim: true
  },
  description: {
    type: String,
    default: ''
  },
  vehicleType: {
    type: String,
    enum: ['E-Scooter', 'E-Bike', 'E-Car', 'E-Bus', 'E-Truck', 'Other'],
    default: 'E-Scooter'
  },
  items: [bomItemSchema],
  totalCost: {
    type: Number,
    default: 0,
    min: 0
  },
  currency: {
    type: String,
    default: 'INR'
  },
  status: {
    type: String,
    enum: ['Draft', 'Active', 'Archived'],
    default: 'Draft'
  },
  version: {
    type: Number,
    default: 1
  },
  parentVersionId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'BOM',
    default: null
  },
  createdBy: {
    type: String,
    default: 'System'
  },
  metadata: {
    type: mongoose.Schema.Types.Mixed,
    default: {}
  },
  createdAt: {
    type: Date,
    default: Date.now
  },
  updatedAt: {
    type: Date,
    default: Date.now
  }
});

bomSchema.pre('save', function(next) {
  this.totalCost = this.items.reduce((sum, item) => sum + item.totalPrice, 0);
  this.updatedAt = Date.now();
  next();
});

bomSchema.index({ name: 'text', description: 'text' });
bomSchema.index({ vehicleType: 1, status: 1 });

module.exports = mongoose.model('BOM', bomSchema);
