const Product = require('../models/Product');

// AI-based component recommendation engine
async function getAIRecommendations({ vehicleType, budget, existingComponents = [], requirements = {} }) {
  const recommendations = {
    essential: [],
    recommended: [],
    optional: [],
    alternatives: []
  };
  
  // Define essential components by vehicle type
  const essentialCategories = {
    'E-Scooter': ['Battery', 'Motor', 'Controller', 'Charger', 'Frame', 'Brakes'],
    'E-Bike': ['Battery', 'Motor', 'Controller', 'Charger', 'Frame', 'Suspension', 'Brakes'],
    'E-Car': ['Battery', 'Motor', 'Controller', 'Charger', 'Frame', 'Suspension', 'Brakes', 'Electronics'],
    'E-Bus': ['Battery', 'Motor', 'Controller', 'Charger', 'Frame', 'Suspension', 'Brakes', 'Electronics'],
    'E-Truck': ['Battery', 'Motor', 'Controller', 'Charger', 'Frame', 'Suspension', 'Brakes', 'Electronics'],
    'Other': ['Battery', 'Motor', 'Controller']
  };
  
  const categories = essentialCategories[vehicleType] || essentialCategories['E-Scooter'];
  const existingCategories = existingComponents.map(c => c.category);
  
  // Get essential components
  for (let category of categories) {
    if (!existingCategories.includes(category)) {
      const products = await Product.find({
        category,
        isActive: true,
        basePrice: { $lte: budget * 0.3 } // Essential items should be affordable
      })
      .sort({ basePrice: 1 })
      .limit(3);
      
      if (products.length > 0) {
        recommendations.essential.push({
          category,
          products: products.map(p => ({
            id: p._id,
            name: p.name,
            partNumber: p.partNumber,
            price: p.basePrice,
            specifications: p.specifications,
            reason: `Essential component for ${vehicleType}`
          }))
        });
      }
    }
  }
  
  // Get recommended components (performance enhancers)
  const recommendedCategories = ['Electronics', 'Wiring'];
  for (let category of recommendedCategories) {
    if (!existingCategories.includes(category)) {
      const products = await Product.find({
        category,
        isActive: true,
        basePrice: { $lte: budget * 0.15 }
      })
      .sort({ basePrice: -1 }) // Higher quality first
      .limit(2);
      
      if (products.length > 0) {
        recommendations.recommended.push({
          category,
          products: products.map(p => ({
            id: p._id,
            name: p.name,
            partNumber: p.partNumber,
            price: p.basePrice,
            specifications: p.specifications,
            reason: `Improves ${category.toLowerCase()} performance`
          }))
        });
      }
    }
  }
  
  // Find alternatives for existing components
  for (let component of existingComponents) {
    const alternatives = await Product.find({
      category: component.category,
      _id: { $ne: component.productId },
      isActive: true,
      basePrice: { $lt: component.price * 1.2 } // Within 20% price range
    })
    .sort({ basePrice: 1 })
    .limit(2);
    
    if (alternatives.length > 0) {
      recommendations.alternatives.push({
        original: {
          id: component.productId,
          name: component.name,
          price: component.price
        },
        alternatives: alternatives.map(p => ({
          id: p._id,
          name: p.name,
          partNumber: p.partNumber,
          price: p.basePrice,
          savings: component.price - p.basePrice,
          specifications: p.specifications
        }))
      });
    }
  }
  
  // Calculate total cost estimate
  const totalEstimate = calculateTotalEstimate(recommendations, existingComponents);
  
  return {
    vehicleType,
    budget,
    recommendations,
    totalEstimate,
    budgetRemaining: budget - totalEstimate,
    confidence: calculateConfidence(recommendations, budget)
  };
}

function calculateTotalEstimate(recommendations, existingComponents) {
  let total = existingComponents.reduce((sum, c) => sum + (c.price || 0), 0);
  
  recommendations.essential.forEach(item => {
    if (item.products.length > 0) {
      total += item.products[0].price; // Use cheapest option
    }
  });
  
  recommendations.recommended.forEach(item => {
    if (item.products.length > 0) {
      total += item.products[0].price;
    }
  });
  
  return total;
}

function calculateConfidence(recommendations, budget) {
  const essentialCount = recommendations.essential.length;
  const recommendedCount = recommendations.recommended.length;
  const totalSuggestions = essentialCount + recommendedCount;
  
  if (totalSuggestions === 0) return 0;
  
  let confidence = (essentialCount / 6) * 60 + (recommendedCount / 2) * 40;
  
  // Adjust based on budget
  if (budget > 100000) confidence += 10;
  else if (budget < 50000) confidence -= 10;
  
  return Math.min(100, Math.max(0, confidence));
}

module.exports = {
  getAIRecommendations
};
