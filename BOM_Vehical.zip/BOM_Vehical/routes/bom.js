const express = require('express');
const router = express.Router();
const BOM = require('../models/BOM');
const Product = require('../models/Product');
const Version = require('../models/Version');
const { calculateCost, optimizeBOM } = require('../services/costEngine');
const axios = require('axios');

// Get all BOMs
router.get('/', async (req, res) => {
  try {
    const { status, vehicleType, page = 1, limit = 20 } = req.query;
    const query = {};
    
    if (status) query.status = status;
    if (vehicleType) query.vehicleType = vehicleType;
    
    const boms = await BOM.find(query)
      .populate('items.productId')
      .limit(limit * 1)
      .skip((page - 1) * limit)
      .sort({ updatedAt: -1 });
    
    const total = await BOM.countDocuments(query);
    
    res.json({
      boms,
      totalPages: Math.ceil(total / limit),
      currentPage: page,
      total
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Get BOM by ID (with product details for display - explicitly fetch product names)
router.get('/:id', async (req, res) => {
  try {
    const bom = await BOM.findById(req.params.id).lean();
    
    if (!bom) {
      return res.status(404).json({ error: 'BOM not found' });
    }
    
    // Attach product name/details to each item (so frontend always gets component names)
    const itemsWithProduct = await Promise.all((bom.items || []).map(async (item, idx) => {
      const rawId = item.productId;
      let productIdStr = null;
      if (rawId) {
        if (typeof rawId === 'string') {
          productIdStr = rawId.trim();
        } else if (rawId && typeof rawId === 'object') {
          productIdStr = rawId._id ? String(rawId._id) : (rawId.toString ? rawId.toString() : String(rawId));
        } else {
          productIdStr = String(rawId);
        }
      }
      let product = null;
      if (productIdStr) {
        try {
          const found = await Product.findById(productIdStr)
            .select('name category basePrice partNumber')
            .lean();
          if (found && found.name) {
            product = {
              _id: String(found._id),
              name: String(found.name),
              category: found.category ? String(found.category) : '',
              basePrice: found.basePrice != null ? found.basePrice : item.unitPrice,
              partNumber: found.partNumber ? String(found.partNumber) : ''
            };
            console.log(`BOM item ${idx}: Found product "${product.name}" for ID ${productIdStr}`);
          } else {
            console.warn(`BOM item ${idx}: Product not found or missing name for ID ${productIdStr}`);
          }
        } catch (e) {
          console.error(`BOM item ${idx}: Error fetching product ${productIdStr}:`, e.message);
        }
      } else {
        console.warn(`BOM item ${idx}: No productId found`);
      }
      return {
        productId: productIdStr,
        quantity: item.quantity || 1,
        unitPrice: item.unitPrice != null ? item.unitPrice : (product ? product.basePrice : 0),
        totalPrice: item.totalPrice != null ? item.totalPrice : ((item.unitPrice != null ? item.unitPrice : (product ? product.basePrice : 0)) * (item.quantity || 1)),
        notes: item.notes || '',
        product: product
      };
    }));
    
    const result = {
      ...bom,
      items: itemsWithProduct
    };
    
    // Update prices from external API
    const updatedBom = await updatePricesFromAPI(result);
    
    res.json(updatedBom);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Create new BOM
router.post('/', async (req, res) => {
  try {
    const bomData = req.body;
    
    // Validate and populate product details
    for (let item of bomData.items) {
      const product = await Product.findById(item.productId);
      if (!product) {
        return res.status(400).json({ error: `Product ${item.productId} not found` });
      }
      
      // Get real-time price
      const realTimePrice = await getRealTimePrice(product.partNumber);
      item.unitPrice = realTimePrice || product.basePrice;
      item.totalPrice = item.unitPrice * item.quantity;
    }
    
    const bom = new BOM(bomData);
    await bom.save();
    
    // Create initial version
    await createVersion(bom, 'Initial version');
    
    const populatedBom = await BOM.findById(bom._id)
      .populate('items.productId');
    
    res.status(201).json(populatedBom);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

// Update BOM
router.put('/:id', async (req, res) => {
  try {
    const bom = await BOM.findById(req.params.id);
    if (!bom) {
      return res.status(404).json({ error: 'BOM not found' });
    }
    
    // Create version before update (use unpopulated bom - productId is ObjectId)
    await createVersion(bom, req.body.changes || 'BOM updated');
    
    // Build update payload with only allowed fields; ensure every item has unitPrice/totalPrice
    const updateData = {
      name: req.body.name,
      description: req.body.description || '',
      vehicleType: req.body.vehicleType || 'E-Scooter',
      status: req.body.status || 'Draft',
      version: bom.version + 1,
      updatedAt: new Date()
    };
    
    if (req.body.items && Array.isArray(req.body.items)) {
      updateData.items = [];
      for (const item of req.body.items) {
        const productId = item.productId && (item.productId._id || item.productId);
        const product = await Product.findById(productId);
        const unitPrice = product
          ? (await getRealTimePrice(product.partNumber)) || product.basePrice
          : (item.unitPrice != null ? Number(item.unitPrice) : 0);
        const quantity = Math.max(1, parseInt(item.quantity, 10) || 1);
        const totalPrice = unitPrice * quantity;
        updateData.items.push({
          productId: productId,
          quantity,
          unitPrice,
          totalPrice
        });
      }
    }
    
    const updatedBom = await BOM.findByIdAndUpdate(
      req.params.id,
      updateData,
      { new: true, runValidators: true }
    ).populate('items.productId');
    
    res.json(updatedBom);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

// Delete BOM
router.delete('/:id', async (req, res) => {
  try {
    const bom = await BOM.findByIdAndDelete(req.params.id);
    if (!bom) {
      return res.status(404).json({ error: 'BOM not found' });
    }
    res.json({ message: 'BOM deleted successfully' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Optimize BOM cost
router.post('/:id/optimize', async (req, res) => {
  try {
    const bom = await BOM.findById(req.params.id)
      .populate('items.productId');
    
    if (!bom) {
      return res.status(404).json({ error: 'BOM not found' });
    }
    
    const optimizedBOM = await optimizeBOM(bom, req.body.targetPrice);
    res.json(optimizedBOM);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Predict cost
router.post('/predict', async (req, res) => {
  try {
    const { items, vehicleType } = req.body;
    const prediction = await calculateCost(items, vehicleType);
    res.json(prediction);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Helper function to get real-time price from API
async function getRealTimePrice(partNumber) {
  try {
    // Simulate API call - Replace with actual pricing API
    // Example: const response = await axios.get(`https://pricing-api.com/products/${partNumber}`);
    // return response.data.price;
    
    // For demo, return null to use base price
    return null;
  } catch (error) {
    console.error('Error fetching real-time price:', error);
    return null;
  }
}

// Helper function to update prices from API (bom can be Mongoose doc or lean object)
async function updatePricesFromAPI(bom) {
  const updatedItems = [];
  for (const item of bom.items || []) {
    const partNumber = (item.product && item.product.partNumber) ||
      (item.productId && typeof item.productId === 'object' && item.productId.partNumber);
    if (partNumber) {
      const realTimePrice = await getRealTimePrice(partNumber);
      if (realTimePrice != null && realTimePrice !== item.unitPrice) {
        item.unitPrice = realTimePrice;
        item.totalPrice = realTimePrice * (item.quantity || 1);
      }
    }
    updatedItems.push(item);
  }
  bom.items = updatedItems;
  bom.totalCost = updatedItems.reduce((sum, item) => sum + (item.totalPrice || 0), 0);
  return bom;
}

// Helper function to create version
async function createVersion(bom, changes) {
  const previousVersion = await Version.findOne({ bomId: bom._id })
    .sort({ versionNumber: -1 });
  
  const versionNumber = previousVersion ? previousVersion.versionNumber + 1 : 1;
  const costDifference = previousVersion 
    ? bom.totalCost - previousVersion.totalCost 
    : 0;
  
  const version = new Version({
    bomId: bom._id,
    versionNumber,
    changes,
    items: bom.items.map(item => ({
      productId: item.productId && (item.productId._id || item.productId),
      quantity: item.quantity,
      unitPrice: item.unitPrice,
      totalPrice: item.totalPrice,
      action: 'modified'
    })),
    totalCost: bom.totalCost,
    costDifference
  });
  
  await version.save();
  return version;
}

module.exports = router;
